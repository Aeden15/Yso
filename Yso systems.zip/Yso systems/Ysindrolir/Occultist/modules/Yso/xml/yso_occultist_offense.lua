--========================================================--
-- yso_occultist_offense.lua
-- Occultist single-target offense core for Yso.
--
-- Design goals:
--   • Plug into existing Yso queue / pulse architecture.
--   • Respect softlock_gate + sightgate drop-ins.
--   • Stay conservative and readable so you can extend it.
--========================================================--

Yso       = Yso       or {}
Yso.off   = Yso.off   or {}
Yso.off.oc = Yso.off.oc or {}

local Off = Yso.off.oc

------------------------------------------------------------
-- Config / state
------------------------------------------------------------

Off.cfg = Off.cfg or {}

-- Affliction score at/above this is treated as "stuck".
Off.cfg.stuck_score = Off.cfg.stuck_score or 100

-- Simple duel-mode identifier (you can switch later if you add more routes).
Off.cfg.mode = Off.cfg.mode or "duel"   -- duel | custom

-- Default EQ queue flag for eq-only payloads.
Off.qtype_eq    = Off.qtype_eq    or "eq"
Off.qtype_eqbal = Off.qtype_eqbal or "eq"

-- Minimal kelp-bury config so softlock_gate has sane defaults.
Off.cfg.kelp_bury = Off.cfg.kelp_bury or {
  enabled  = true,
  entities = {
    asthma      = "bubonis",
    clumsiness  = "storm",
    healthleech = "worm",
    sensitivity = "slime",
  },
  -- Optional: where to take sensitivity from once you extend this.
  sensitivity_followup = "slime",
}

-- Stand-prepend is respected by softlock_gate and sightgate.
if Off.cfg.prepend_stand == nil then
  Off.cfg.prepend_stand = true
end

Off.state = Off.state or {
  enabled = false,
  mode    = Off.cfg.mode,
  ai      = "lock",   -- future expansion hook
  tarot   = "aeon",   -- future expansion hook
}

------------------------------------------------------------
-- Small helpers
------------------------------------------------------------

local function _trim(s)
  return (tostring(s or ""):gsub("^%s+",""):gsub("%s+$",""))
end

local function _lc(s) return _trim(s):lower() end

local function _vitals()
  return (gmcp and gmcp.Char and gmcp.Char.Vitals) or {}
end

local function _eq_ready()
  if Yso.state and type(Yso.state.eq_ready) == "function" then
    local ok, v = pcall(Yso.state.eq_ready)
    if ok then return v == true end
  end
  local v = _vitals()
  local eq = v.eq or v.equilibrium
  return eq == true or tostring(eq or "") == "1"
end

local function _ent_ready()
  if Yso.state and type(Yso.state.ent_ready) == "function" then
    local ok, v = pcall(Yso.state.ent_ready)
    if ok then return v == true end
  end
  return true
end

local function _current_target()
  if type(Yso.get_target) == "function" then
    local ok, v = pcall(Yso.get_target)
    if ok then return _trim(v) end
  end
  if type(Yso.target) == "string" then
    return _trim(Yso.target)
  end
  if Yso.state and type(Yso.state.target) == "string" then
    return _trim(Yso.state.target)
  end
  local g = rawget(_G, "gmcp")
  if g and g.Char and g.Char.Target and type(g.Char.Target.name) == "string" then
    return _trim(g.Char.Target.name)
  end
  return ""
end

local function _target_is_valid(tgt)
  tgt = _trim(tgt)
  if tgt == "" then return false end
  if type(Yso.target_is_valid) == "function" then
    local ok, v = pcall(Yso.target_is_valid, tgt)
    if ok then return v == true end
  end
  return true
end

local function _aff_scores()
  if type(affstrack) == "table" and type(affstrack.score) == "table" then
    return affstrack.score
  end
  return {}
end

local function _aff_score(aff, scores)
  aff = _lc(aff)
  if aff == "" then return 0 end

  -- Prefer AK score export when available.
  if Yso.oc and Yso.oc.ak and type(Yso.oc.ak.get_aff_score) == "function" then
    local ok, v = pcall(Yso.oc.ak.get_aff_score, aff)
    if ok then
      local n = tonumber(v)
      if n then return n end
    end
  end

  local v = scores and scores[aff]
  if type(v) == "table" then
    if type(v.current) == "number" then
      v = v.current
    elseif type(v.score) == "number" then
      v = v.score
    else
      v = 0
    end
  end
  v = tonumber(v or 0) or 0
  return v
end

local function _aff_stuck(aff, scores)
  local stuck = Off.cfg.stuck_score or 100
  return _aff_score(aff, scores) >= stuck
end

local function _emit(payload, opts)
  opts = opts or {}
  opts.reason = opts.reason or "occ_offense"

  if Yso.emit and type(Yso.emit) == "function" then
    return Yso.emit(payload, opts) == true
  end

  local Q = Yso.queue
  if Q and type(Q.emit) == "function" then
    local ok = pcall(Q.emit, payload)
    return ok == true
  end

  -- Very small fallback: send eq/class directly if lane helpers exist.
  local sent = false
  if payload.eq and Q and type(Q.eq_clear) == "function" then
    local ok = pcall(Q.eq_clear, payload.eq); sent = sent or (ok == true)
  elseif payload.eq and type(send) == "function" then
    send(payload.eq); sent = true
  end

  if payload.class and Q and type(Q.class_clear) == "function" then
    local ok = pcall(Q.class_clear, payload.class); sent = sent or (ok == true)
  elseif payload.class and type(send) == "function" then
    send(payload.class); sent = true
  end

  return sent
end

local function _maybe_shieldbreak(tgt)
  if not (Yso.off and Yso.off.util and type(Yso.off.util.maybe_shieldbreak) == "function") then
    return nil
  end
  local ok, cmd = pcall(Yso.off.util.maybe_shieldbreak, tgt)
  cmd = ok and _trim(cmd) or ""
  return (cmd ~= "") and cmd or nil
end

------------------------------------------------------------
-- Public toggles / getters
------------------------------------------------------------

local function _echo(msg)
  if type(cecho) == "function" then
    cecho(string.format("<orange>[Yso:Occ] %s\n", tostring(msg)))
  elseif type(echo) == "function" then
    echo(string.format("[Yso:Occ] %s\n", tostring(msg)))
  end
end

function Off.set_mode(mode)
  mode = _lc(mode)
  if mode == "" then return Off.state.mode end
  Off.state.mode = mode
  Off.cfg.mode = mode
  _echo("Offense mode set to "..mode)
  return mode
end

function Off.get_mode()
  return Off.state.mode or Off.cfg.mode or "duel"
end

function Off.set_ai(ai)
  ai = _lc(ai)
  if ai == "" then return Off.state.ai end
  Off.state.ai = ai
  _echo("AI profile set to "..ai)
  return ai
end

function Off.get_ai()
  return Off.state.ai or "lock"
end

function Off.set_tarot(tarot)
  tarot = _lc(tarot)
  if tarot == "" then return Off.state.tarot end
  Off.state.tarot = tarot
  _echo("Tarot focus set to "..tarot)
  return tarot
end

function Off.get_tarot()
  return Off.state.tarot or "aeon"
end

function Off.on()
  Off.state.enabled = true
  Yso.off.oc.enabled = true
  _echo("Occultist offense ON.")
  if Yso.pulse and type(Yso.pulse.wake) == "function" then
    Yso.pulse.wake("oc:on")
  end
end

function Off.off()
  Off.state.enabled = false
  Yso.off.oc.enabled = false
  _echo("Occultist offense OFF.")
end

function Off.toggle(on)
  if on == nil then
    if Off.state.enabled then Off.off() else Off.on() end
  elseif on == true then
    Off.on()
  else
    Off.off()
  end
end

------------------------------------------------------------
-- Target helpers
------------------------------------------------------------

function Off.set_target(tgt)
  tgt = _trim(tgt)
  if tgt == "" then return false end

  if Yso.targeting and type(Yso.targeting.set) == "function" then
    local ok = pcall(Yso.targeting.set, tgt, "offense")
    if ok then return true end
  end

  if type(Yso.set_target) == "function" then
    local ok = pcall(Yso.set_target, tgt)
    if ok then return true end
  end

  rawset(_G, "target", tgt)
  Yso.target = tgt
  return true
end

function Off.resolve_target()
  local t = _current_target()
  if t == "" then return "" end
  if not _target_is_valid(t) then return "" end
  return t
end

------------------------------------------------------------
-- Simple EQ-only attack helper
------------------------------------------------------------

function Off.attack_eqonly()
  local tgt = Off.resolve_target()
  if tgt == "" or not _eq_ready() then return false end
  local scores = _aff_scores()

  local cmd = _maybe_shieldbreak(tgt)
  if not cmd then
    if not _aff_stuck("healthleech", scores) then
      cmd = string.format("instill %s with healthleech", tgt)
    elseif not _aff_stuck("sensitivity", scores) then
      cmd = string.format("instill %s with sensitivity", tgt)
    elseif not _aff_stuck("paralysis", scores) then
      cmd = string.format("instill %s with paralysis", tgt)
    else
      cmd = string.format("warp %s", tgt)
    end
  end

  return _emit({ eq = cmd }, { reason = "oc_attack_eqonly" })
end

------------------------------------------------------------
-- Kelp-bury stub (for softlock_gate wrapper)
------------------------------------------------------------

-- softlock_gate.lua wraps this to run Off.try_softlock_setup() first.
function Off.try_kelp_bury(t, afftbl)
  -- Base implementation intentionally minimal; returns false so that
  -- once soft-lock is satisfied, control falls back to the main tick
  -- logic below.
  return false
end

------------------------------------------------------------
-- Main offense tick (pulse-driven)
------------------------------------------------------------

local function _build_eq_cmd(tgt, scores, phase)
  -- Shieldbreak pre-emption.
  if _eq_ready() then
    local sb = _maybe_shieldbreak(tgt)
    if sb then return sb end
  end

  -- During SOFTLOCK_SETUP / KELP_BUILD, lean on core affs.
  if phase == "SOFTLOCK_SETUP" or phase == "KELP_BUILD" then
    if not _aff_stuck("asthma", scores) then
      return string.format("instill %s with asthma", tgt)
    end
    if not _aff_stuck("slickness", scores) then
      return string.format("instill %s with slickness", tgt)
    end
    if not _aff_stuck("anorexia", scores) then
      return string.format("regress %s", tgt)
    end
  end

  -- Post-softlock: keep pressure using healthleech/sensitivity/paralysis.
  if not _aff_stuck("healthleech", scores) then
    return string.format("instill %s with healthleech", tgt)
  end
  if not _aff_stuck("sensitivity", scores) then
    return string.format("instill %s with sensitivity", tgt)
  end
  if not _aff_stuck("paralysis", scores) then
    return string.format("instill %s with paralysis", tgt)
  end

  -- If we can utter truename, prefer that over raw damage.
  if Yso.occ and Yso.occ.truebook and type(Yso.occ.truebook.can_utter) == "function" then
    local ok, can = pcall(Yso.occ.truebook.can_utter, tgt)
    if ok and can then
      return string.format("utter truename %s", tgt)
    end
  end

  -- Default fallback: WARP damage.
  return string.format("warp %s", tgt)
end

local function _build_entity_cmd(tgt, scores, phase)
  if not _ent_ready() then return nil end
  if not (Off.sg_pick_missing_aff and Off.sg_entity_cmd_for_aff) then
    return nil
  end

  local aff = Off.sg_pick_missing_aff(phase, tgt, scores)
  if not aff or aff == "" then return nil end
  local cmd = Off.sg_entity_cmd_for_aff(aff, tgt)
  cmd = _trim(cmd)
  if cmd == "" then return nil end
  return cmd
end

function Off.tick(reasons)
  if not (Off.state and Off.state.enabled == true) then return end

  local tgt = Off.resolve_target()
  if tgt == "" then return end

  local scores = _aff_scores()

  -- Optional sight-gate (only runs when you have an explicit need_sight flag).
  if type(Off.queue_attend_if_needed) == "function" then
    local ok, handled = pcall(Off.queue_attend_if_needed, tgt, scores, "tick")
    if ok and handled then return end
  end

  -- Soft-lock / kelp-bury wrapper: Off.try_kelp_bury() is wrapped by softlock_gate.lua
  if type(Off.try_kelp_bury) == "function" then
    local ok, handled = pcall(Off.try_kelp_bury, tgt, scores)
    if ok and handled then return end
  end

  -- Phase detection from sightgate.lua, if present.
  local phase = "UNRAVEL"
  if type(Off.phase) == "function" then
    local ok, p = pcall(Off.phase, tgt, scores)
    if ok and type(p) == "string" and p ~= "" then
      phase = p
    end
  end

  -- Build lane payload.
  local payload = {}

  if _eq_ready() then
    payload.eq = _build_eq_cmd(tgt, scores, phase)
  end

  local ent_cmd = _build_entity_cmd(tgt, scores, phase)
  if ent_cmd then
    payload.class = ent_cmd
  end

  if not payload.eq and not payload.class then
    return
  end

  _emit(payload, { reason = "occ_offense" })
end

------------------------------------------------------------
-- Pulse registration
------------------------------------------------------------

local function _ensure_pulse()
  if not (Yso and Yso.pulse and type(Yso.pulse.register) == "function") then
    return
  end
  Yso.pulse.state = Yso.pulse.state or { reg = Yso.pulse.state and Yso.pulse.state.reg or {} }
  local reg = Yso.pulse.state.reg
  if reg and reg["occultist_offense"] then return end

  pcall(Yso.pulse.register, "occultist_offense", function(reasons)
    Off.tick(reasons)
  end, { order = 2, enabled = true })
end

_ensure_pulse()

--========================================================--

