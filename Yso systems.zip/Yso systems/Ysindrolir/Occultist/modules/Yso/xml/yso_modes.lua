--========================================================--
-- yso_modes.lua (DROP-IN)
-- Purpose:
--   • Central "mode of play" switch for Yso
--   • Modes: "hunt", "combat", "party"
--   • Party subroutes: "aff" (team affliction), "dam" (team damage)
--   • Non-destructive: only flips optional toggles if present
--
-- API:
--   Yso.mode.set("hunt"|"combat"|"party"[, reason])
--   Yso.mode.toggle([reason])                 -- toggles hunt <-> combat
--   Yso.mode.is_hunt() / is_combat() / is_party()
--   Yso.mode.set_party_route("aff"|"dam"[, reason])
--   raiseEvent("yso.mode.changed", old, new, reason) on mode change
--   raiseEvent("yso.party.route.changed", old, new, reason) on party route change
--
-- Suggested aliases (tempAlias, auto-registered if available):
--   ^mode$                               -> Yso.mode.echo()
--   ^mode\s+(hunt|combat|party)$         -> Yso.mode.set(matches[2], "alias")
--   ^mhunt$                              -> Yso.mode.set("hunt", "alias")   (avoids clobbering Legacy ^hunt$ basher)
--   ^combat$                             -> Yso.mode.set("combat", "alias")
--   ^party(?:\s+(aff|dam))?$             -> set party mode; optional route
--   ^partyroute\s+(aff|dam)$             -> Yso.mode.set_party_route(matches[2])
--   ^mt$                                 -> Yso.mode.toggle("alias")
--========================================================--

-- Normalize namespace so both _G.Yso and _G.yso point to the same table.
_G.Yso = _G.Yso or _G.yso or {}
_G.yso = _G.Yso

Yso = _G.Yso
Yso.mode = Yso.mode or {}

local M = Yso.mode

local function _now()
  if type(getEpoch) == "function" then
    local t = tonumber(getEpoch()) or os.time()
    if t > 20000000000 then t = t / 1000 end
    return t
  end
  return os.time()
end

local function _norm(s)
  s = tostring(s or ""):lower()
  s = s:gsub("^%s+",""):gsub("%s+$","")
  if s == "pvp" then s = "combat" end
  if s == "pve" then s = "hunt" end
  return s
end

local function _echo(msg)
  if not (M.cfg and M.cfg.echo) then return end
  if type(cecho) == "function" then
    -- NOTE: avoid "\\n" escape sequences; use a literal LF via string.char(10).
    cecho("<aquamarine>[Yso] <reset>" .. tostring(msg) .. "<reset>" .. string.char(10))
  elseif type(echo) == "function" then
    echo("[Yso] " .. tostring(msg) .. string.char(10))
  end
end

M.cfg = M.cfg or {
  default = "combat",
  echo = true,
}

-- Optional profiles: only applied if destination tables exist.
M.profile = M.profile or {
  hunt = {
    toggles = {
      offense  = false,
      affcall  = false,
      debug    = false,
      travel   = true,
      autoloot = true,
    },
  },
  combat = {
    toggles = {
      offense  = true,
      affcall  = true,
      debug    = true,
      travel   = false,
      autoloot = false,
    },
  },
  party = {
    toggles = {
      offense  = true,
      affcall  = true,
      debug    = true,
      travel   = false,
      autoloot = false,
      party    = true,
    },
  },
}

M.state = M.state or _norm(M.cfg.default or "combat")
M.last_change = M.last_change or _now()
M.last_reason = M.last_reason or "init"

-- Party subroute state + simple ownership (so we don't stop user-started modules)
M.party = M.party or {
  route       = "dam",   -- aff|dam
  last_change = _now(),
  last_reason = "init",
  owns = { dam = false, aff = false },
}

local function _route_norm(r)
  r = _norm(r)
  if r == "dmg" then r = "dam" end
  return r
end

local function _gd()
  return (Yso and Yso.off and Yso.off.oc and (Yso.off.oc.dmg or Yso.off.oc.group_damage)) or nil
end

local function _party_apply(reason)
  local route = _route_norm(M.party and M.party.route or "dam")

  -- Leaving party: release owned modules.
  if M.state ~= "party" then
    local gd = _gd()
    if gd and M.party and M.party.owns and M.party.owns.dam and type(gd.stop) == "function" then
      pcall(gd.stop)
    end
    if M.party and M.party.owns then
      M.party.owns.dam = false
      M.party.owns.aff = false
    end
    return
  end
  -- Party mode: ensure route driver.
  if route == "dam" then
    local gd = _gd()
    -- Start GD only if not already running
    if gd and gd.state and gd.state.enabled ~= true and type(gd.start) == "function" then
      pcall(gd.start)
    end
    -- Always claim ownership when entering dam route, regardless of prior state
    if M.party and M.party.owns then
      M.party.owns.dam = true
      M.party.owns.aff = false
    end
    _echo('Party route <yellow>dam<reset>: group damage ' .. ((gd and gd.state and gd.state.enabled) and 'ON' or 'requested'))

  elseif route == "aff" then
    -- Placeholder: hook your future team-affliction driver here.
    local gd = _gd()
    if gd and M.party and M.party.owns and M.party.owns.dam and type(gd.stop) == "function" then
      pcall(gd.stop)
      M.party.owns.dam = false
    end
    _echo("Party route <yellow>aff<reset>: (driver not yet implemented)")
  end
end

function M.is_hunt()   return M.state == "hunt" end
function M.is_combat() return M.state == "combat" end
function M.is_party()  return M.state == "party" end

function M.party_route()
  return _route_norm(M.party and M.party.route or "dam")
end

function M.set_party_route(route, reason)
  route = _route_norm(route)
  if route ~= "aff" and route ~= "dam" then
    _echo(("Invalid party route: <yellow>%s<reset> (use aff|dam)"):format(tostring(route)))
    return false
  end

  local old = M.party_route()
  if old == route then
    if M.party then M.party.last_reason = reason or M.party.last_reason end
    return true
  end

  M.party.route = route
  M.party.last_change = _now()
  M.party.last_reason = reason or "manual"

  _party_apply("route:"..tostring(reason or "manual"))

  if type(raiseEvent) == "function" then
    raiseEvent("yso.party.route.changed", old, route, M.party.last_reason)
  end

  return true
end

function M.echo()
  if M.is_party() then
    _echo(("Mode: <yellow>%s<reset> (route: <yellow>%s<reset>)"):format(M.state, M.party_route()))
  else
    _echo(("Mode: <yellow>%s<reset>"):format(M.state))
  end
end

function M.apply_profile(mode)
  mode = _norm(mode)
  local p = M.profile and M.profile[mode]
  if not p or not p.toggles then return end

  Yso.toggles = Yso.toggles or {}
  for k, v in pairs(p.toggles) do
    local cur = Yso.toggles[k]
    if cur == nil or type(cur) == "boolean" then
      Yso.toggles[k] = (v == true)
    end
  end
end

function M.set(mode, reason)
  mode = _norm(mode)
  if mode ~= "hunt" and mode ~= "combat" and mode ~= "party" then
    _echo(("Invalid mode: <yellow>%s<reset> (use hunt|combat|party)"):format(tostring(mode)))
    return false
  end

  local old = M.state
  if old == mode then
    M.last_reason = reason or M.last_reason
    -- Still apply party route if we're in party and route exists.
    if mode == "party" then _party_apply("mode_noop") end
    return true
  end

  M.state = mode
  M.last_change = _now()
  M.last_reason = reason or "manual"

  M.apply_profile(mode)

  if mode == "party" then
    _echo(("Mode set to <yellow>%s<reset> (route: <yellow>%s<reset>)"):format(mode, M.party_route()))
  else
    _echo(("Mode set to <yellow>%s<reset>"):format(mode))
  end

  if type(raiseEvent) == "function" then
    raiseEvent("yso.mode.changed", old, mode, M.last_reason)
  end

  _party_apply("mode:"..tostring(M.last_reason))

  return true
end

function M.toggle(reason)
  -- Only toggles hunt <-> combat (party is an explicit mode)
  if M.is_hunt() then
    return M.set("combat", reason or "toggle")
  elseif M.is_combat() then
    return M.set("hunt", reason or "toggle")
  else
    return false
  end
end

-- Optional helpers for triggers
function M.on_engage(reason)    return M.set("combat", reason or "engage") end
function M.on_disengage(reason) return M.set("hunt",   reason or "disengage") end

-- ---------------- tempAlias registrations ----------------
M._alias = M._alias or {}
local function _kill_alias(id) if id then pcall(killAlias, id) end end

if type(tempAlias) == "function" then
  _kill_alias(M._alias.mode)
  M._alias.mode = tempAlias([[^mode$]], function() if Yso.mode and Yso.mode.echo then Yso.mode.echo() end end)

  _kill_alias(M._alias.mode_set)
  M._alias.mode_set = tempAlias([[^mode\s+(hunt|combat|party)$]], function() Yso.mode.set(matches[2], "alias") end)

  _kill_alias(M._alias.hunt)
  -- NOTE: Do NOT register ^hunt$ here; Legacy uses it for actual hunting automation.
  M._alias.mhunt = tempAlias([[^mhunt$]], function() Yso.mode.set("hunt", "alias") end)
_kill_alias(M._alias.combat)
  M._alias.combat = tempAlias([[^combat$]], function() Yso.mode.set("combat", "alias") end)

  _kill_alias(M._alias.party)
  M._alias.party = tempAlias([[^party(?:\s+(aff|dam))?$]], function()
    local r = matches[2]
    if r and r ~= "" then
      Yso.mode.set("party", "alias")
      Yso.mode.set_party_route(r, "alias")
    else
      Yso.mode.set("party", "alias")
    end
  end)

  _kill_alias(M._alias.partyroute)
  M._alias.partyroute = tempAlias([[^partyroute\s+(aff|dam)$]], function() Yso.mode.set_party_route(matches[2], "alias") end)

  _kill_alias(M._alias.mt)
  M._alias.mt = tempAlias([[^mt$]], function() Yso.mode.toggle("alias") end)
end
  -- One-time reminder for party mode / group damage route.
  M._tip_shown = M._tip_shown or false
  if (not M._tip_shown) and type(cecho) == "function" then
    M._tip_shown = true
    cecho("<aquamarine>[Yso] <reset>Tip: type <white>party<reset> to use the group-damage route (default: <white>party dam<reset>)."..string.char(10))
  end

--========================================================--
