--========================================================--
-- yso_mode_autoswitch.lua (DROP-IN)
-- Purpose:
--   • Auto-switch Yso.mode between hunt/combat using:
--       1) Duel/Spar start/end lines (deterministic)
--       2) Aggression cooldown line (fallback)
--       3) PvP contact heuristics via gmcp.Room.Players + combat text
--
-- Notes:
--   • Does NOT require you to manually type "cooldowns", but if you do,
--     it will parse "Aggression: X minutes and Y seconds." automatically.
--   • Includes a "sniffer" that records lines containing duel/spar so you
--     can identify the exact start/end messages from your own output.
--
-- Where to place:
--   • Load AFTER yso_modes.lua (recommended), but safe standalone.
--========================================================--

-- Normalize namespace so both _G.Yso and _G.yso point to the same table.
_G.Yso = _G.Yso or _G.yso or {}
_G.yso = _G.Yso
Yso = _G.Yso

Yso.sep = Yso.sep or ";;"

-- Minimal fallback if yso_modes.lua isn't loaded.
Yso.mode = Yso.mode or {}
do
  local M = Yso.mode
  M.cfg = M.cfg or { echo = true }
  M.state = M.state or "combat"
  local function _echo(msg)
    if not M.cfg.echo then return end
    if type(cecho) == "function" then
      cecho("<aquamarine>[Yso] <reset>" .. msg .. "<reset>\n")
    elseif type(echo) == "function" then
      echo("[Yso] " .. msg .. "\n")
    end
  end
  M.is_hunt   = M.is_hunt   or function() return M.state == "hunt" end
  M.is_combat = M.is_combat or function() return M.state == "combat" end
  M.is_party  = M.is_party  or function() return M.state == "party" end
  M.set = M.set or function(mode, _reason)
    mode = tostring(mode or ""):lower()
    if mode ~= "hunt" and mode ~= "combat" and mode ~= "party" then return false end
    if M.state ~= mode then
      M.state = mode
      _echo(("Mode set to <yellow>%s<reset>"):format(mode))
      if type(raiseEvent) == "function" then raiseEvent("yso.mode.changed", nil, mode, _reason or "auto") end
    end
    return true
  end
end

Yso.mode.auto = Yso.mode.auto or {}
local A = Yso.mode.auto

local function _now()
  return (type(getEpoch) == "function" and getEpoch()) or os.time()
end

local function _echo(msg)
  if not (Yso.mode and Yso.mode.cfg and Yso.mode.cfg.echo) then return end
  if type(cecho) == "function" then
    cecho("<aquamarine>[Yso] <reset>" .. msg .. "<reset>\n")
  elseif type(echo) == "function" then
    echo("[Yso] " .. msg .. "\n")
  end
end

-- ---------- configuration ----------
A.cfg = A.cfg or {
  debug = false,              -- extra echoes
  sniff = true,               -- record duel/spar-related lines
  sniff_max = 40,             -- ring buffer size

  -- How long we consider ourselves "in combat" after a PvP contact line,
  -- unless duel/spar forces combat explicitly.
  contact_hold = 20,

  -- If you DO see "Aggression: ..." lines, we use them to set combat_until.
  use_aggression = true,
}

-- ---------- state ----------
A.state = A.state or {
  forced = nil,               -- { kind="duel"/"spar", opponent="name", since=epoch }
  combat_until = 0,           -- epoch time until which we prefer combat
  room_players = {},          -- lowercase set of player names in room
  sniff = {},                 -- ring buffer of interesting lines
}

local function _sniff(line)
  if not A.cfg.sniff then return end
  local buf = A.state.sniff
  buf[#buf + 1] = { t = _now(), line = line }
  while #buf > (A.cfg.sniff_max or 40) do table.remove(buf, 1) end
end

function A.dump_sniff()
  local buf = A.state.sniff
  _echo(("Sniff buffer (%d lines):"):format(#buf))
  for i = 1, #buf do
    local row = buf[i]
    _echo(("[%02d] %s"):format(i, row.line))
  end
end

local function _in_room_players(name)
  if not name or name == "" then return false end
  return A.state.room_players[name:lower()] == true
end

local function _sync_mode(reason)
  -- Respect manual party mode (do not autoswitch while party is active).
  if Yso.mode and ((type(Yso.mode.is_party)=="function" and Yso.mode.is_party()) or (tostring(Yso.mode.state or "") == "party")) then
    return
  end
  -- Forced duel/spar overrides everything.
  if A.state.forced then
    if not (Yso.mode.is_combat and Yso.mode.is_combat()) then
      Yso.mode.set("combat", reason or "forced")
      if A.cfg.debug then _echo("Auto: forced combat ("..A.state.forced.kind..")") end
    end
    return
  end

  -- Otherwise, use combat_until.
  if _now() < (A.state.combat_until or 0) then
    if not (Yso.mode.is_combat and Yso.mode.is_combat()) then
      Yso.mode.set("combat", reason or "timer")
      if A.cfg.debug then _echo("Auto: combat (timer)") end
    end
  else
    if not (Yso.mode.is_hunt and Yso.mode.is_hunt()) then
      Yso.mode.set("hunt", reason or "idle")
      if A.cfg.debug then _echo("Auto: hunt (idle)") end
    end
  end
end

-- ---------- public helpers ----------
function A.force_combat(kind, opponent, reason)
  A.state.forced = { kind = kind or "duel", opponent = opponent or "", since = _now(), reason = reason or "line" }
  _sync_mode("force:"..tostring(kind))
  _echo(("Auto: <yellow>%s<reset> started%s"):format(
    tostring(kind or "duel"),
    (opponent and opponent ~= "") and (" vs <yellow>"..opponent.."<reset>") or ""
  ))
end

function A.clear_force(reason)
  if A.state.forced then
    _echo(("Auto: <yellow>%s<reset> ended%s"):format(
      tostring(A.state.forced.kind),
      (A.state.forced.opponent and A.state.forced.opponent ~= "") and (" vs <yellow>"..A.state.forced.opponent.."<reset>") or ""
    ))
  end
  A.state.forced = nil
  A.state.combat_until = 0
  _sync_mode(reason or "force_end")
end

function A.bump_combat(seconds, reason)
  seconds = tonumber(seconds or 0) or 0
  if seconds <= 0 then return end
  local untilt = _now() + seconds
  if untilt > (A.state.combat_until or 0) then
    A.state.combat_until = untilt
  end
  _sync_mode(reason or "bump")
end

-- ---------- GMCP: room players ----------
A._eh = A._eh or {}

local function _update_room_players()
  local set = {}
  local pkt = gmcp and gmcp.Room and gmcp.Room.Players
  -- Common shapes:
  --   gmcp.Room.Players = { {name="Foo"}, {name="Bar"} } or { "Foo", "Bar" }
  if type(pkt) == "table" then
    for _, row in ipairs(pkt) do
      if type(row) == "table" and row.name then
        set[tostring(row.name):lower()] = true
      elseif type(row) == "string" then
        set[row:lower()] = true
      end
    end
  end
  A.state.room_players = set
end

local function _safe(fn)
  return function(...)
    local ok, err = pcall(fn, ...)
    if not ok and A.cfg.debug then _echo("Auto ERR: "..tostring(err)) end
  end
end

local function _kill_ae(id) if id then killAnonymousEventHandler(id) end end
_kill_ae(A._eh.room_players)
A._eh.room_players = registerAnonymousEventHandler("gmcp.Room.Players", _safe(_update_room_players))

-- ---------- Aggression parsing ----------
local function _parse_aggression(line)
  -- expects something like:
  --   "Aggression: 7 minutes and 58 seconds."
  --   "Aggression: 58 seconds."
  --   "Aggression: 7 minutes."
  local mins = line:match("(%d+)%s+minutes?")
  local secs = line:match("(%d+)%s+seconds?")
  mins = tonumber(mins or 0) or 0
  secs = tonumber(secs or 0) or 0
  local total = mins * 60 + secs
  return total
end

-- ---------- Duel/Spar line classifiers ----------
local function _lower(s) return tostring(s or ""):lower() end

local function _looks_like_duel_start(s)
  s = _lower(s)
  return s:find("duel", 1, true)
     and (s:find("accept", 1, true) or s:find("accepted", 1, true) or s:find("begins", 1, true) or s:find("has begun", 1, true))
     and not s:find("declin", 1, true)
end

local function _looks_like_duel_end(s)
  s = _lower(s)
  return s:find("duel", 1, true)
     and (s:find("has ended", 1, true) or s:find("is over", 1, true) or s:find("ends", 1, true) or s:find("conclud", 1, true) or s:find("you have won", 1, true) or s:find("you have lost", 1, true))
end

local function _looks_like_spar_start(s)
  s = _lower(s)
  return (s:find("spar", 1, true) or s:find("sparring", 1, true))
     and (s:find("accept", 1, true) or s:find("accepted", 1, true) or s:find("begins", 1, true) or s:find("has begun", 1, true) or s:find("agreed", 1, true))
end

local function _looks_like_spar_end(s)
  s = _lower(s)
  return (s:find("spar", 1, true) or s:find("sparring", 1, true))
     and (s:find("has ended", 1, true) or s:find("is over", 1, true) or s:find("ends", 1, true) or s:find("conclud", 1, true) or s:find("complete", 1, true))
end

-- Best-effort opponent extraction (safe if it fails).
local function _extract_name(line)
  -- Try to catch a capitalized first token before "'s" or " challenges" etc.
  local n = line:match("^([A-Z][%a%-']+)")
  if n and n ~= "You" then return n end
  n = line:match("challenge%s+from%s+([A-Z][%a%-']+)")
  if n then return n end
  n = line:match("against%s+([A-Z][%a%-']+)")
  if n then return n end
  return ""
end

-- ---------- Triggers ----------
A._trig = A._trig or {}

local function _kill_tr(id) if id then killTrigger(id) end end

-- (1) Aggression line from COOLDOWNS output
_kill_tr(A._trig.aggression)
A._trig.aggression = tempRegexTrigger(
  [[^Aggression:\s+(.+)$]],
  _safe(function()
    if not A.cfg.use_aggression then return end
    local line = matches[0] or ""
    _sniff(line)

    local secs = _parse_aggression(line)
    if secs > 0 then
      A.state.combat_until = _now() + secs
      _sync_mode("aggression")
      if A.cfg.debug then _echo("Auto: aggression parsed -> "..secs.."s") end
    else
      -- If aggression is 0, do not force hunt if we're in a duel/spar.
      if not A.state.forced then
        A.state.combat_until = 0
        _sync_mode("aggression0")
      end
    end
  end)
)

-- (2) Duel/spar sniffer + switcher (broad net; deterministic checks inside)
_kill_tr(A._trig.duel_spar)
A._trig.duel_spar = tempRegexTrigger(
  [[(?i)\b(duel|spar|sparring|challenge)\b]],
  _safe(function()
    local line = matches[0] or ""
    _sniff(line)

    if _looks_like_duel_start(line) then
      A.force_combat("duel", _extract_name(line), "line")
    elseif _looks_like_duel_end(line) then
      if A.state.forced and A.state.forced.kind == "duel" then
        A.clear_force("duel_end")
      end
    elseif _looks_like_spar_start(line) then
      A.force_combat("spar", _extract_name(line), "line")
    elseif _looks_like_spar_end(line) then
      if A.state.forced and A.state.forced.kind == "spar" then
        A.clear_force("spar_end")
      end
    end
  end)
)

-- (3) PvP contact heuristic: "<Name> attacks you" (only if <Name> is a room player)
_kill_tr(A._trig.pvp_hit_you)
A._trig.pvp_hit_you = tempRegexTrigger(
  [[^([A-Z][A-Za-z\-' ]+?)\s+(?:attacks|hits|strikes|slashes|stabs|smashes|bashes)\s+you\b]],
  _safe(function()
    local who = matches[2] or ""
    if who ~= "" and _in_room_players(who) then
      A.bump_combat(A.cfg.contact_hold or 20, "pvp_contact_in")
      if A.cfg.debug then _echo("Auto: PvP contact from "..who) end
    end
  end)
)

-- (4) PvP contact heuristic: "You hit <Name>" (only if <Name> is a room player)
_kill_tr(A._trig.you_hit_pvp)
A._trig.you_hit_pvp = tempRegexTrigger(
  [[^You\s+(?:attack|hit|strike|slash|stab|smash|bash)\s+([A-Z][A-Za-z\-' ]+?)\b]],
  _safe(function()
    local who = matches[2] or ""
    if who ~= "" and _in_room_players(who) then
      A.bump_combat(A.cfg.contact_hold or 20, "pvp_contact_out")
      if A.cfg.debug then _echo("Auto: PvP contact to "..who) end
    end
  end)
)

_echo("Mode autoswitch loaded (duel/spar + aggression + pvp contact)")
--========================================================--
