--Group damage offense logic
--========================================================--
-- group_damage.lua  (Achaea / Occultist / Yso)
--  • Group damage automation (party / team damage):
--      Track: healthleech, sensitivity, nausea
--      Setup: build missing pieces using EQ instills + entity pressure
--      Spam:  WARP <tgt> on EQ, rotate entity damage/aff pressure
--
--  • Uses Yso.emit() lane table => combo payload transport (default separator: &&)
--  • Payload modes (GLOBAL, via Yso.cfg.payload_mode):
--      - "paired": prefer pairing ENTITY with EQ/BAL; if ENTITY is down, EQ/BAL may still fire (no hard stall)
--      - "as_available": emit lanes independently as they come up
--
--  Requirement (dry-test update 2026-02-25):
--    - Always try to include an ENTITY lane command in the opener/setup payload when possible.
--      Example: order entourage kill <tgt> && instill <tgt> with <aff> && command <entity> at <tgt>
--========================================================--

Yso = Yso or {}
Yso.off = Yso.off or {}
Yso.off.oc = Yso.off.oc or {}

-- Canonical group damage driver lives here:
Yso.off.oc.group_damage = Yso.off.oc.group_damage or {}
local GD = Yso.off.oc.group_damage

-- Compatibility aliases (callers may refer to these):
Yso.off.oc.dmg = GD
Yso.off.oc.gd_simple = GD

GD.cfg = GD.cfg or {
  enabled = false,
  echo = true,

  -- setup behavior when <2/3 are present
  setup_enable = true,

  -- one-shot entourage opener (FREE lane)
  opener_enable = true,
  opener_cmd = "order entourage kill %t",

  -- OFF cleanup (balanceless), gated by (EQ or BAL) being ready
  off_passive_cmd = "order loyals passive",

  -- entity rotation (when no hard-need exists)
  -- NOTE: Keep these as plain entity names; builder will format "command <ent> at <tgt>".
  entity_rotation = { "firelord", "hound", "bloodleech", "storm" },

  -- if true and clumsiness is not present, prefer storm clumsiness once.
  prefer_storm_clumsiness = true,

  -- if true, prefer worm to establish healthleech/nausea when missing
  prefer_worm_for_healthleech = true,

  -- Avoid wasting overlapping aff applications (e.g., worm tick healthleech vs instill healthleech)
  avoid_overlap = true,
  -- Worm is a setup DoT: one application lasts ~20s (chewing/maggots ticks).
  -- Treat as "one cast per ~20s per target" (do NOT spam command worm every entity balance).
  worm_duration_s = 20,
  worm_refresh_lead_s = 1.0, -- allow refresh when <= 1s remains (rarely needed)
  -- Sycophant (Domination: COMMAND SYCOPHANT) applies Rixil for ~30s.
  -- Treat as "one cast per ~30s per target" (do NOT spam command sycophant every entity balance).
  prefer_sycophant_rixil = true,
  sycophant_duration_s = 30,
  sycophant_refresh_lead_s = 1.0,
  -- In as_available, do not piggyback other lanes onto the lane that woke.
  -- Uses pulse reasons (lane:eq/lane:bal/lane:class) when present.
  freestyle_isolate_lanes = true,

  -- minimum send throttles (milliseconds)
  dupe_window_ms = 120,
}

GD.state = GD.state or {
  enabled = false,
  opener_sent_for = "",
  rr_idx = 0,
  stop_pending = false,
  last_room_id = "",
  last_target = "",
  worm_until = {},
  sycophant_until = {},
  sycophant_timers = {},
}

-- Anti-tumble / Empress rescue state (Lust+Empress recovery)
GD.state.tumble = GD.state.tumble or { target = "", dir = "", at = 0, until_t = 0, fired = false }
GD.state.empress = GD.state.empress or { pending = false, target = "", dir = "", started_at = 0, last_try = 0, fail_until = 0 }
local function _trim(s) return (tostring(s or ""):gsub("^%s+",""):gsub("%s+$","")) end
local function _lc(s) return _trim(s):lower() end

local function _now()
  -- Use canonical clock (seconds, handles getEpoch ms) to keep worm timers sane.
  if Yso and Yso.util and type(Yso.util.now) == "function" then
    local ok,v = pcall(Yso.util.now)
    v = ok and tonumber(v) or nil
    if v then return v end
  end
  if type(getEpoch) == "function" then
    local ok,v = pcall(getEpoch)
    v = ok and tonumber(v) or nil
    if v then
      if v > 1e12 then v = v / 1000 end
      return v
    end
  end
  return os.time()
end

-- Worm (Domination: COMMAND WORM) behaves like a ~20s DoT.
-- We gate re-commanding per-target using a simple timer so we don't spam entity balance.
local function _worm_until_tbl()
  GD.state.worm_until = GD.state.worm_until or {}
  return GD.state.worm_until
end

local function _worm_until(tkey)
  return tonumber((_worm_until_tbl())[tkey] or 0) or 0
end

local function _worm_active(tkey)
  local until_t = _worm_until(tkey)
  if until_t <= 0 then return false end
  return _now() < until_t
end

local function _worm_should_refresh(tkey)
  local lead = tonumber(GD.cfg.worm_refresh_lead_s or 1.0) or 1.0
  local until_t = _worm_until(tkey)
  if until_t <= 0 then return true end
  local remaining = until_t - _now()
  return remaining <= lead
end

local function _worm_mark(tkey)
  local dur = tonumber(GD.cfg.worm_duration_s or 20) or 20
  (_worm_until_tbl())[tkey] = _now() + dur
end

local function _worm_clear(tkey)
  (_worm_until_tbl())[tkey] = nil
end

-- Sycophant (Domination: COMMAND SYCOPHANT) applies Rixil for ~30s.
-- We gate re-commanding per-target using a simple timer so we don't spam entity balance.
local function _syc_until_tbl()
  GD.state.sycophant_until = GD.state.sycophant_until or {}
  return GD.state.sycophant_until
end

local function _syc_until(tkey)
  return tonumber((_syc_until_tbl())[tkey] or 0) or 0
end

local function _syc_active(tkey)
  local until_t = _syc_until(tkey)
  return (until_t > 0 and _now() < until_t) or false
end

local function _syc_should_refresh(tkey)
  local lead = tonumber(GD.cfg.sycophant_refresh_lead_s or 1.0) or 1.0
  local until_t = _syc_until(tkey)
  if until_t <= 0 then return true end
  local remaining = until_t - _now()
  return remaining <= lead
end

local function _syc_mark(tkey)
  local dur = tonumber(GD.cfg.sycophant_duration_s or 30) or 30
  (_syc_until_tbl())[tkey] = _now() + dur
  -- Optional hard clear timer (helps when clocks drift or state is reloaded mid-fight)
  GD.state.sycophant_timers = GD.state.sycophant_timers or {}
  local tid = GD.state.sycophant_timers[tkey]
  if tid and type(killTimer) == "function" then pcall(killTimer, tid) end
  if type(tempTimer) == "function" then
    GD.state.sycophant_timers[tkey] = tempTimer(dur + 0.25, function()
      GD.state.sycophant_timers[tkey] = nil
      (_syc_until_tbl())[tkey] = nil
    end)
  end
end

local function _syc_clear(tkey)
  (_syc_until_tbl())[tkey] = nil
end

local function _target()
  if type(Yso.get_target) == "function" then
    return _trim(Yso.get_target() or "")
  end
  if type(Yso.target) == "string" then return _trim(Yso.target) end
  if Yso.state and type(Yso.state.target) == "string" then return _trim(Yso.state.target) end
  return ""
end

local function _eq_ready()
  if Yso.state and type(Yso.state.eq_ready) == "function" then
    local ok,v = pcall(Yso.state.eq_ready); if ok then return v==true end
  end
  local v = gmcp and gmcp.Char and gmcp.Char.Vitals or {}
  return tostring(v.eq or v.equilibrium or "") == "1" or v.eq == true or v.equilibrium == true
end

local function _bal_ready()
  if Yso.state and type(Yso.state.bal_ready) == "function" then
    local ok,v = pcall(Yso.state.bal_ready); if ok then return v==true end
  end
  local v = gmcp and gmcp.Char and gmcp.Char.Vitals or {}
  return tostring(v.bal or v.balance or "") == "1" or v.bal == true or v.balance == true
end

local function _dry_run()
  return (Yso.net and Yso.net.cfg and Yso.net.cfg.dry_run == true) or false
end

local function _room_id()
  local info = gmcp and gmcp.Room and gmcp.Room.Info or {}
  return tostring(info.num or info.vnum or info.id or "")
end

local function _tgt_valid(tgt)
  -- In dry-run, allow dummy targets so you can validate payload composition.
  if _dry_run() then return true end

  if type(Yso.target_is_valid) == "function" then
    local ok,v = pcall(Yso.target_is_valid, tgt); if ok then return v==true end
  end
  if type(Yso.room_has) == "function" then
    local ok,v = pcall(Yso.room_has, tgt); if ok then return v==true end
  end
  return true -- no GMCP -> don’t false-negative
end

local function _set_loyals_hostile(v)
  if not Yso.state then return end
  if type(Yso.state.loyals_hostile) == "function" then
    pcall(Yso.state.loyals_hostile, v)
  else
    Yso.state.loyals_hostile = (v == true)
  end
end

local function _ent_ready()
  if Yso.state and type(Yso.state.ent_ready) == "function" then
    local ok,v = pcall(Yso.state.ent_ready); if ok then return v==true end
  end
  -- fallback: allow, but lane throttling in Yso.emit / locks should backoff if the server rejects
  return true
end

-- Prefer AK score exports if present, then raw affstrack.score, then Yso.tgt.has_aff
local function _aff_score(aff)
  aff = _lc(aff)
  if aff == "" then return 0 end
  if Yso.oc and Yso.oc.ak and type(Yso.oc.ak.get_aff_score) == "function" then
    local ok,v = pcall(Yso.oc.ak.get_aff_score, aff)
    if ok then return tonumber(v or 0) or 0 end
  end
  if type(affstrack) == "table" and type(affstrack.score) == "table" then
    return tonumber(affstrack.score[aff] or 0) or 0
  end
  local tgt = _target()
  if tgt ~= "" and Yso.tgt and type(Yso.tgt.has_aff) == "function" then
    return Yso.tgt.has_aff(tgt, aff) and 100 or 0
  end
  return 0
end

local function _has_aff(aff) return _aff_score(aff) >= 100 end

local function _count_core_affs()
  local n = 0
  if _has_aff("healthleech") then n = n + 1 end
  if _has_aff("sensitivity") then n = n + 1 end
  if _has_aff("nausea") then n = n + 1 end
  return n
end

local function _payload_mode()
  if type(Yso.get_payload_mode)=="function" then return Yso.get_payload_mode() end
  return tostring((Yso.cfg and Yso.cfg.payload_mode) or "as_available")
end

local function _echo(msg)
  if GD.cfg.echo and type(cecho) == "function" then
    -- NOTE: avoid "\\n" escape sequences; use a literal LF via string.char(10).
    cecho(string.format("<orange>[Yso:GD] <reset>%s%s", tostring(msg), string.char(10)))
  end
end

------------------------------------------------------------
-- Opener (FREE lane): entourage attack, single-shot per target
-- NOTE: we don't mark the opener as "sent" until we successfully emit it.
------------------------------------------------------------
local function _want_opener(tgt)
  if not GD.cfg.opener_enable then return nil end
  if tgt == "" then return nil end
  if GD.state.opener_sent_for ~= _lc(tgt) then
    return (tostring(GD.cfg.opener_cmd or "order entourage kill %t"):gsub("%%t", tgt))
  end
  return nil
end

local function _mark_opener_sent(tgt)
  if tgt and tgt ~= "" then
    GD.state.opener_sent_for = _lc(tgt)
  end
end

------------------------------------------------------------
-- Entity selection helpers
------------------------------------------------------------
local function _rr_pick()
  local list = GD.cfg.entity_rotation or {}
  if type(list) ~= "table" or #list == 0 then return nil end
  GD.state.rr_idx = (tonumber(GD.state.rr_idx) or 0) + 1
  local idx = ((GD.state.rr_idx - 1) % #list) + 1
  return tostring(list[idx] or ""):lower()
end

local function _cmd_entity(ent, tgt, extra)
  ent = tostring(ent or ""):lower()
  tgt = tostring(tgt or "")
  if ent == "" or tgt == "" then return nil end
  if extra and extra ~= "" then
    return ("command %s at %s %s"):format(ent, tgt, extra)
  end
  return ("command %s at %s"):format(ent, tgt)
end

-- Select ONE entity command for this tick.
-- Priority:
--   1) If healthleech or nausea missing: worm pressure (establishes/maintains)
--   2) If clumsiness missing and prefer_storm_clumsiness: storm clumsiness
--   3) Otherwise: rotate firelord/hound/bloodleech/storm
local function _pick_entity_cmd(tgt)
  if not _ent_ready() then return nil end

  if GD.cfg.prefer_worm_for_healthleech and ((not _has_aff("healthleech")) or (not _has_aff("nausea"))) then
    local tkey = _lc(tgt)
    -- Worm lasts ~20s; don't re-command until it is expiring for this target.
    if _worm_should_refresh(tkey) then
      return _cmd_entity("worm", tgt)
    end
  end

  if (GD.cfg.prefer_sycophant_rixil == true) then
    local tkey2 = _lc(tgt)
    if _syc_should_refresh(tkey2) then
      return _cmd_entity("sycophant", tgt)
    end
  end

  if GD.cfg.prefer_storm_clumsiness and (not _has_aff("clumsiness")) then
    return _cmd_entity("storm", tgt)
  end

  local pick = _rr_pick()
  if pick == "firelord" then
    -- keep healthleech pressure; also contributes damage
    return _cmd_entity("firelord", tgt, "healthleech")
  elseif pick == "hound" then
    return _cmd_entity("hound", tgt)
  elseif pick == "bloodleech" then
    return _cmd_entity("bloodleech", tgt)
  elseif pick == "storm" then
    -- if we can still push clumsiness, do so; else plain storm
    if not _has_aff("clumsiness") then
      return _cmd_entity("storm", tgt)
    end
    return _cmd_entity("storm", tgt)
  end

  -- fallback
  return _cmd_entity("firelord", tgt, "healthleech")
end

------------------------------------------------------------
-- Setup planner (<2/3): always try to pair an entity filler when possible
------------------------------------------------------------
local function _plan_setup(tgt)
  if not GD.cfg.setup_enable then return {} end
  local p = {}

  -- EQ piece: sensitivity first, then fallback healthleech if no entity is available
  if not _has_aff("sensitivity") and _eq_ready() then
    p.eq = ("instill %s with sensitivity"):format(tgt)
  elseif (not _has_aff("healthleech")) and (not _ent_ready()) and _eq_ready() then
    -- if entity lane is down, try instilling HL so we don't stall entirely
    -- (but don't waste it if worm is already established for this target)
    local tkey = _lc(tgt)
    if not (GD.cfg.avoid_overlap and (_worm_active(tkey) or _has_aff("worm"))) then
      p.eq = ("instill %s with healthleech"):format(tgt)
    end
  end

  -- ENTITY piece (always try)
  p.class = _pick_entity_cmd(tgt)

  -- Mode semantics:
  --   • paired: prefer pairing ENTITY with a balance lane, but do not hard-stall if ENTITY is down.
  --     Pairing/selection is handled downstream in Yso.queue.commit().
  --   • as_available: lanes can fire independently.
  --
  -- as_available (and paired fallback): lanes can fire independently
  if not p.eq then p.eq = nil end
  if not p.class then p.class = nil end
  return p
end

------------------------------------------------------------
-- Spam planner (>=2/3): WARP on EQ + rotate entity pressure
------------------------------------------------------------
local function _plan_spam(tgt)
  local p = {}

  local eq_cmd = _eq_ready() and ("warp %s"):format(tgt) or nil
  local ent_cmd = _pick_entity_cmd(tgt)

  -- In paired mode we still stage whatever is available; commit() will pair when possible.
  if eq_cmd then p.eq = eq_cmd end
  if ent_cmd then p.class = ent_cmd end
  return p
end

------------------------------------------------------------
-- Public API
------------------------------------------------------------
local function _ensure_registered()
  if not (Yso and Yso.pulse and type(Yso.pulse.register) == 'function') then return false end
  if Yso.pulse.state and Yso.pulse.state.reg and Yso.pulse.state.reg['group_damage'] then return true end
  local ok = pcall(Yso.pulse.register, 'group_damage', function(reasons) GD.tick(reasons) end, { order = 0, enabled = true })
  return ok == true
end

function GD.toggle(on)
  -- Always ensure the pulse handler exists so OFF-cleanup can run on the next wake.
  _ensure_registered()

  local want
  if on == nil then
    want = not (GD.state.enabled == true)
  else
    want = (on == true)
  end

  if want then
    GD.state.enabled = true
    GD.state.stop_pending = false
    GD.state.opener_sent_for = ""
    GD.state.last_room_id = ""
    _echo("Group damage ON. payload_mode="..tostring(_payload_mode()))
  else
    GD.state.enabled = false
    GD.state.stop_pending = true
    _set_loyals_hostile(false)
    _echo("Group damage OFF (pending: order loyals passive on next EQ/BAL ready).")
  end

  if Yso.pulse and type(Yso.pulse.wake) == "function" then
    Yso.pulse.wake("group_damage:toggle")
  end
end
-- Back-compat helper: route to GLOBAL payload mode
function GD.set_mode(mode)
  mode = _lc(mode)
  if mode == "freestyle" then mode = "as_available" end
  if mode == "combo" then mode = "paired" end
  if mode ~= "paired" and mode ~= "as_available" then
    _echo("Invalid mode. Use: paired | as_available")
    return false
  end

  if type(Yso.set_payload_mode)=="function" then
    Yso.set_payload_mode(mode)
  else
    Yso.cfg = Yso.cfg or {}
    Yso.cfg.payload_mode = mode
    _echo("payload_mode="..mode)
  end

  if Yso.pulse and type(Yso.pulse.wake) == "function" then
    Yso.pulse.wake("payload_mode")
  end
  return true
end

------------------------------------------------------------
-- Anti-tumble / Empress rescue (stateful)
--  • Wired by triggers in yso_offense_coordination.lua:
--      - tumble_begin -> GD.mark_tumble(tgt, dir)
--      - tumble_out   -> GD.mark_tumble_out(tgt, DIRU)
--  • Wired by Tarot triggers:
--      - Empress fail  -> GD.mark_empress_fail()
--      - Lust success  -> GD.mark_lust_landed(tgt)
------------------------------------------------------------
local function _tgt_present(tgt)
  tgt = _trim(tgt)
  if tgt == "" then return false end
  if _dry_run() then return true end
  if type(Yso.room_has) == "function" then
    local ok,v = pcall(Yso.room_has, tgt)
    if ok then return v == true end
  end
  -- GMCP fallback: scan Room.Players if present
  local players = gmcp and gmcp.Room and (gmcp.Room.Players or gmcp.Room.players)
  if type(players) == "table" then
    for _,p in ipairs(players) do
      local name = (type(p)=="table" and (p.name or p.id)) or p
      if _lc(name) == _lc(tgt) then return true end
    end
  end
  return false
end

local function _emit_lane(lane, cmd, reason)
  cmd = _trim(cmd)
  if cmd == "" then return false end
  reason = reason or "gd:anti"
  if Yso.emit and type(Yso.emit) == "function" then
    local payload = {}; payload[lane] = cmd
    return (Yso.emit(payload, { reason = reason, solo = true, dupe_window_ms = GD.cfg.dupe_window_ms }) == true)
  end
  -- fallback: push directly if lane helper exists
  local Q = Yso.queue
  if Q then
    if lane == "free" and type(Q.free) == "function" then local ok=pcall(Q.free, cmd); return ok==true end
    if lane == "bal"  and type(Q.bal_clear) == "function" then local ok=pcall(Q.bal_clear, cmd); return ok==true end
    if lane == "eq"   and type(Q.eq_clear) == "function" then local ok=pcall(Q.eq_clear, cmd); return ok==true end
  end
  if type(send) == "function" then send(cmd); return true end
  return false
end

function GD.mark_tumble(tgt, dir)
  tgt = _trim(tgt); dir = _trim(dir)
  if tgt == "" then return end
  local now = _now()
  local T = GD.state.tumble
  T.target  = tgt
  T.dir     = dir
  T.at      = now
  T.until_t = now + 0.75
  T.fired   = false
  if Yso.pulse and type(Yso.pulse.wake) == "function" then
    Yso.pulse.wake("gd:tumble_begin")
  end
end

function GD.mark_tumble_out(tgt, diru)
  tgt = _trim(tgt); diru = _trim(diru)
  if tgt == "" then return end
  GD.mark_tumble(tgt, diru)
  local now = _now()
  local E = GD.state.empress
  E.pending    = true
  E.target     = tgt
  E.dir        = diru
  E.started_at = now
  -- don't clear fail_until here: if we just failed empress, keep the backoff
  if Yso.pulse and type(Yso.pulse.wake) == "function" then
    Yso.pulse.wake("gd:tumble_out")
  end
end

function GD.mark_empress_fail()
  local now = _now()
  local E = GD.state.empress
  E.fail_until = now + 10.0
  -- keep pending true so we retry after backoff (once Lust lands)
  if GD.cfg.echo then _echo("Empress failed: backing off 10s (need Lust).") end
end

function GD.mark_lust_landed(tgt)
  tgt = _trim(tgt)
  if tgt == "" then return end
  local E = GD.state.empress
  if E.pending and _lc(E.target) == _lc(tgt) then
    E.fail_until = 0
    if Yso.pulse and type(Yso.pulse.wake) == "function" then
      Yso.pulse.wake("gd:lust_landed")
    end
  end
end

local function _maybe_antitumble(now)
  local T = GD.state.tumble
  if T.target == "" then return false end
  if now > (tonumber(T.until_t) or 0) then
    T.target = ""; T.dir = ""; T.fired = false
    return false
  end
  if T.fired then return false end

  -- Prefer reacting for current target only (prevents stale target spam).
  local tgt = _target()
  if tgt == "" or _lc(tgt) ~= _lc(T.target) then return false end

  -- SM dominate is EQ lane; Lust is BAL lane.
  local sm_ready = false
  if Yso and type(Yso.soulmaster_ready) == "function" then
    local ok,v = pcall(Yso.soulmaster_ready); if ok then sm_ready = (v == true) end
  else
    sm_ready = (rawget(_G, "soulmaster_ready") == true)
  end

  if sm_ready and Yso and Yso.occ and type(Yso.occ.sm_cmd_tumble) == "function" then
    if not _eq_ready() then return false end
    local ok,cmd = pcall(Yso.occ.sm_cmd_tumble, tgt, T.dir)
    cmd = _trim(ok and cmd or "")
    if cmd ~= "" then
      _echo(("%s TUMBLE BEGIN -> Soulmaster dominate (anti-tumble)"):format(tgt))
      if _emit_lane("eq", cmd, "gd:antitumble") then
        T.fired = true
        return true
      end
    end
  end

  -- fallback: Lust
  if not _bal_ready() then return false end
  _echo(("%s TUMBLE BEGIN -> Lust (SM not ready/usable)"):format(tgt))
  if _emit_lane("bal", ("fling lust at %s"):format(tgt), "gd:antitumble") then
    T.fired = true
    return true
  end
  return false
end

local function _maybe_empress(now)
  local E = GD.state.empress
  if not E.pending then return false end

  local tgt = _trim(E.target)
  if tgt == "" then E.pending = false; return false end

  -- Clear pending if target is already back in the room.
  if _tgt_present(tgt) then
    E.pending = false
    return false
  end

  -- Hard timeout (don’t keep this pending forever if presence tracking is missing).
  if E.started_at ~= 0 and (now - (tonumber(E.started_at) or 0)) > 15.0 then
    E.pending = false
    return false
  end

  if now < (tonumber(E.fail_until) or 0) then return false end
  if not _bal_ready() then return false end

  if (now - (tonumber(E.last_try) or 0)) < 0.9 then return false end
  E.last_try = now

  _echo(("%s TUMBLED OUT -> Empress pull (%s)"):format(tgt, tostring(E.dir or "?")))
  _emit_lane("free", "outd empress", "gd:empress")
  return _emit_lane("bal", ("fling empress %s"):format(tgt), "gd:empress")
end

------------------------------------------------------------
-- Main tick
------------------------------------------------------------
function GD.tick(reasons)
  -- OFF cleanup: "order loyals passive" is balanceless, but we only emit it on a ready EQ/BAL lane.
  if GD.state.stop_pending then
    if _eq_ready() or _bal_ready() then
      local cmd = tostring(GD.cfg.off_passive_cmd or "order loyals passive")
      local sent = false

      if Yso.emit and type(Yso.emit) == "function" then
        sent = (Yso.emit({ free = cmd }, { reason = "group_damage:off", solo = true, dupe_window_ms = GD.cfg.dupe_window_ms }) == true)
      elseif Yso.queue and type(Yso.queue.free) == "function" then
        local ok = pcall(Yso.queue.free, cmd); sent = ok == true
      elseif type(send) == "function" then
        send(cmd); sent = true
      end

      if sent then
        _set_loyals_hostile(false)
        GD.state.stop_pending = false
        GD.state.opener_sent_for = ""
        GD.state.last_room_id = ""
        _echo("Group damage OFF. loyals passive.")
      end
    end
    return
  end

  if not GD.state.enabled then return end

  local now = _now()
  -- Anti-tumble / Empress rescue (only while GD is enabled)
  _maybe_antitumble(now)
  _maybe_empress(now)

  -- Reset opener when we move rooms (prevents stale-target opener spam).
  local rid = _room_id()
  if rid ~= "" and rid ~= tostring(GD.state.last_room_id or "") then
    GD.state.last_room_id = rid
    GD.state.opener_sent_for = ""
  end

  local tgt = _target()
  if tgt == "" then return end

  -- Target change resets one-shot setup state (worm/opener).
  local tkey = _lc(tgt)
  if GD.state.last_target ~= tkey then
    GD.state.last_target = tkey
    GD.state.rr_idx = 0
  end

  -- Presence gating (GMCP room). Bypassed in dry-run so dummy targets still print payloads.
  if not _tgt_valid(tgt) then return end

  -- Shieldbreak (Gremlin) is EQ-lane and should pre-empt offense cycles.
  if Yso.off and Yso.off.util and type(Yso.off.util.maybe_shieldbreak)=="function" and _eq_ready() then
    local sb = Yso.off.util.maybe_shieldbreak(tgt)
    if sb and sb ~= "" then
      if Yso.emit and type(Yso.emit)=="function" then
        Yso.emit({ eq = sb }, { reason = "shieldbreak", solo = true })
      elseif Yso.queue and type(Yso.queue.eq_clear)=="function" then
        Yso.queue.eq_clear(sb)
      end
      return
    end
  end

  local have = _count_core_affs()
  local p = (have >= 2) and _plan_spam(tgt) or _plan_setup(tgt)

  -- If this is the first tick for this target, enforce:
  --   opener + (optional EQ) + ENTITY  (no opener-only startup)
  local opener = _want_opener(tgt)
  if opener and (not p.class or p.class == "") then
    -- Try to include ENTITY in the opener, but do not stall if the entity lane is currently down.
    p.class = _pick_entity_cmd(tgt)
  end

  local payload = {}
  if opener then payload.free = opener end
  if p.eq then payload.eq = p.eq end
  if p.class then payload.class = p.class end

  -- Overlap guard: avoid wasting healthleech instill when an entity is already providing HL (worm tick / firelord HL).
  if GD.cfg.avoid_overlap and payload.eq and type(payload.eq) == "string" then
    local eqlc = payload.eq:lower()
    if eqlc:match("^%s*instill%s+") and eqlc:find("with%s+healthleech") then
      local clc = tostring(payload.class or ""):lower()
      if clc:find("^%s*command%s+worm") or clc:find("healthleech") or _worm_active(tkey) or _has_aff("worm") then
        -- Prefer sensitivity if it's still missing; otherwise drop the redundant HL instill.
        if (not _has_aff("sensitivity")) and _eq_ready() then
          payload.eq = ("instill %s with sensitivity"):format(tgt)
        else
          payload.eq = nil
        end
      end
    end
  end

  -- Emit via lane-aware payload transport.
  local sent = false
  local mode = _payload_mode()

  -- Helper: derive lane wakes from pulse reasons.
  local wakes = {}
  if type(reasons) == "table" then
    for _,r in ipairs(reasons) do
      r = tostring(r or "")
      if r == "lane:eq" then wakes.eq = true end
      if r == "lane:bal" then wakes.bal = true end
      if r == "lane:class" then wakes.class = true end
    end
  end

  if mode == "as_available" and GD.cfg.freestyle_isolate_lanes == true then
    -- In freestyle, emit ONLY the lane(s) that woke this tick (plus FREE opener).
    local lanes = {}
    if wakes.eq then lanes[#lanes+1] = "eq" end
    if wakes.class then lanes[#lanes+1] = "class" end
    if wakes.bal then lanes[#lanes+1] = "bal" end

    -- If we didn't get explicit lane reasons, fall back to "whatever is ready" but still one lane per tick.
    if #lanes == 0 then
      -- Prefer ENTITY lane first when we do not have explicit wake reasons.
      if payload.class then lanes[#lanes+1] = "class"
      elseif payload.eq then lanes[#lanes+1] = "eq"
      elseif payload.bal then lanes[#lanes+1] = "bal" end
    end

    for i=1,#lanes do
      local lane = lanes[i]
      local p2 = { free = (i == 1 and payload.free or nil) }
      if lane == "eq" then p2.eq = payload.eq
      elseif lane == "bal" then p2.bal = payload.bal
      elseif lane == "class" then p2.class = payload.class end

      local ok_emit = false
      if Yso.emit and type(Yso.emit) == "function" then
        ok_emit = (Yso.emit(p2, { reason = "group_damage", wake_lane = lane, allow_eqbal = true, dupe_window_ms = GD.cfg.dupe_window_ms }) == true)
        sent = ok_emit or sent
      elseif Yso.queue and type(Yso.queue.emit) == "function" then
        local ok = pcall(Yso.queue.emit, p2)
        ok_emit = (ok == true)
        sent = ok_emit or sent
      end

      -- Worm/Sycophant duration latch: if we emitted a worm/sycophant command, mark windows now.
      if ok_emit and p2.class and type(p2.class) == "string" then
        local cl = p2.class:lower()
        if cl:find("^%s*command%s+worm%s+") then
          _worm_mark(tkey)
        elseif cl:find("^%s*command%s+sycophant%s+") then
          _syc_mark(tkey)
        end
      end
    end
  else
    -- paired (combo) or fallback: allow the queue to pair lanes when possible.
    if Yso.emit and type(Yso.emit) == "function" then
      sent = (Yso.emit(payload, { reason = "group_damage", allow_eqbal = true, dupe_window_ms = GD.cfg.dupe_window_ms }) == true)
    elseif Yso.queue and type(Yso.queue.emit) == "function" then
      local ok = pcall(Yso.queue.emit, payload); sent = ok == true
    end
  end
  -- If we successfully emitted a worm/sycophant command (paired mode sends combined lanes), start gates now.
  if sent and payload.class and type(payload.class) == "string" then
    local cl = payload.class:lower()
    if cl:find("^%s*command%s+worm%s+") then
      _worm_mark(tkey)
    elseif cl:find("^%s*command%s+sycophant%s+") then
      _syc_mark(tkey)
    end
  end

  if opener and sent then _mark_opener_sent(tgt) end
end

-- Mudlet/party-mode friendly surface:
function GD.start(arg) GD.toggle(true) end
function GD.stop() GD.toggle(false) end
function GD.status()
  local tgt = _target()
  _echo(string.format("enabled=%s target=%s core=%d/3 (hl=%s sens=%s nausea=%s) payload_mode=%s",
    tostring(GD.state.enabled==true), tostring(tgt),
    _count_core_affs(),
    tostring(_has_aff("healthleech")), tostring(_has_aff("sensitivity")), tostring(_has_aff("nausea")),
    tostring(_payload_mode())
  ))
end

-- Register with pulse bus (so EQ/BAL/ENT wake triggers drive it)
_ensure_registered()
