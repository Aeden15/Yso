--========================================================--
-- Yso_Offense_Coordination.lua  (SUPERSEDING DROP-IN)
--  • Combat mode coordination (NO autostart)
--  • Target auto-clear on death / tumble-out / not-in-room
--  • Slowtime heuristic: "You move sluggishly into action."
--
-- Patch (2026-01-11):
--  • On: "<tgt> begins to tumble towards the <dir>."
--      - If Soulmaster balance NOT ready -> QUEUE BAL_CLEAR: fling lust at <tgt>
--      - Else (Soulmaster ready) -> prefer Soulmaster anti-tumble (if available),
--        otherwise fall back to Lust.
--  • On: "<tgt> tumbles out to the <dir>."
--      - QUEUE FREE: outd empress
--      - QUEUE BAL_CLEAR: fling empress <tgt>
--  • Still marks tumble for group_damage (dmg) module, and won’t break other modules.
--
-- IMPORTANT COMPAT FIX (this drop-in):
--  • Do NOT overwrite Yso.off.oc.toggle() if the Unravel route module already defined it.
--========================================================--

Yso = Yso or {}
Yso.off = Yso.off or {}
Yso.off.oc = Yso.off.oc or {}

-- Only define if Unravel route (or another driver) didn’t already define it.
if type(Yso.off.oc.toggle) ~= "function" then
  function Yso.off.oc.toggle(on)
    if on == nil then
      Yso.off.oc.enabled = not (Yso.off.oc.enabled == true)
    else
      Yso.off.oc.enabled = (on == true)
    end
    if Yso and Yso.pulse and type(Yso.pulse.wake) == "function" then
      Yso.pulse.wake("oc:toggle")
    end
    cecho(string.format("<orange>[Yso] Occultist offense %s.\n", Yso.off.oc.enabled and "ON" or "OFF"))
  end
end


Yso.off.coord = Yso.off.coord or {}
local C = Yso.off.coord

C._ev = C._ev or {}
C._tr = C._tr or {}
C._st = C._st or { tumble_react = { last = {} } }

local function _pkill(fn, id) if id then pcall(fn, id) end end
local function _trim(s) return (tostring(s or ""):gsub("^%s+",""):gsub("%s+$","")) end
local function _lc(s) return _trim(s):lower() end

local function _now()
  if Yso and type(Yso.now) == "function" then return tonumber(Yso.now()) or os.time() end
  if type(getEpoch) == "function" then
    local t = tonumber(getEpoch()) or os.time()
    if t > 20000000000 then t = t / 1000 end
    return t
  end
  return os.time()
end

local function _hotpink(msg)
  if type(cecho) == "function" then
    cecho(string.format("<HotPink>[OFFENSE:] %s\n", msg))
  else
    echo(string.format("[OFFENSE:] %s\n", msg))
  end
end

local function _cur_target()
  if type(Yso.get_target) == "function" then return _trim(Yso.get_target() or "") end
  return _trim((type(Yso.target) == "string" and Yso.target) or (Yso.state and type(Yso.state.target) == "string" and Yso.state.target) or "")
end

local function _is_current(t)
  return _lc(_cur_target()) == _lc(t)
end

local function _clear(reason)
  if type(Yso.clear_target) == "function" then
    Yso.clear_target(reason or "auto")
  end
end

C._tm = C._tm or {}
C._st = C._st or {}
C._st.dead = C._st.dead or { pending = "", at = 0 }

local function _cancel_dead_clear()
  if C._tm.dead_clear then pcall(killTimer, C._tm.dead_clear) end
  C._tm.dead_clear = nil
  C._st.dead.pending = ""
  C._st.dead.at = 0
end

local function _reset_enemy_state_on_starburst(tgt)
  -- AK compatibility: affstrack layouts vary by version.
  --  • Modern: affstrack.score[aff] = number (0..100)
  --  • Some builds: affstrack.score[aff] = { current = number, ... }
  if type(affstrack) == "table" then
    if type(affstrack.score) == "table" then
      for k, v in pairs(affstrack.score) do
        if type(v) == "number" then
          affstrack.score[k] = 0
        elseif type(v) == "table" then
          if type(v.current) == "number" then v.current = 0 end
          if type(v.score) == "number" then v.score = 0 end
        end
      end
    else
      -- Legacy: wipe any numeric .score fields found directly on affstrack entries
      for _, v in pairs(affstrack) do
        if type(v) == "table" and type(v.score) == "number" then v.score = 0 end
      end
    end
  end

  if type(oscore) == "number" then oscore = 0 end
  if type(softscore) == "number" then softscore = 0 end

  if Yso and Yso.tgt and type(Yso.tgt.set_mindseye) == "function" then
    Yso.tgt.set_mindseye(tgt, false, true)
  end
end


local function _schedule_dead_clear(tgt)
  tgt = _trim(tgt)
  if tgt == "" then return end

  _cancel_dead_clear()
  C._st.dead.pending = tgt
  C._st.dead.at = _now()

  C._tm.dead_clear = tempTimer(2.2, function()
    local pend = C._st.dead.pending
    C._tm.dead_clear = nil
    C._st.dead.pending = ""
    C._st.dead.at = 0
    if pend ~= "" and _is_current(pend) then
      _clear("dead")
    end
  end)
end

local function _check_present(src)
  local t = _cur_target()
  if t == "" then return end
  if type(Yso.target_is_valid) ~= "function" then return end

  -- Guard against transient GMCP gaps: require two consecutive misses in a short window
  -- before clearing the current target.
  C._st.presence = C._st.presence or { miss = {}, at = {} }
  local P = C._st.presence

  local ok, valid = pcall(Yso.target_is_valid, t)
  if not ok then return end

  local key = _lc(t)
  if valid then
    P.miss[key] = nil
    P.at[key] = nil
    return
  end

  local now  = _now()
  local last = tonumber(P.at[key] or 0) or 0
  local miss = tonumber(P.miss[key] or 0) or 0

  if miss == 0 or (now - last) > 1.0 then
    P.miss[key] = 1
    P.at[key]   = now
    return
  end

  -- second consecutive miss inside the window => clear
  P.miss[key] = nil
  P.at[key]   = nil
  _clear("not_in_room")
end

local function _offense_active()
  if not (Yso and Yso.off and Yso.off.oc) then return false end

  if Yso.off.oc.enabled == true then return true end

  local GD = Yso.off.oc.dmg or Yso.off.oc.group_damage
  if GD and GD.state and GD.state.enabled == true then return true end

  local DL = Yso.off.oc.duel_limbs
  if DL and DL.state and DL.state.enabled == true then return true end

  return false
end

local function _gd()
  if not (Yso and Yso.off and Yso.off.oc) then return nil end
  return Yso.off.oc.group_damage or Yso.off.oc.dmg
end

local function _gd_enabled()
  local GD = _gd()
  return (GD and GD.state and GD.state.enabled == true) or false
end

local function _q_free(cmd)
  cmd = _trim(cmd)
  if cmd == "" then return false end
  local Q = Yso.queue
  if Q and type(Q.free) == "function" then Q.free(cmd); return true end
  if Q and type(Q.push) == "function" then Q.push(cmd, "free"); return true end
  if type(send) == "function" then send(cmd) end
  return true
end

local function _q_bal_clear(cmd)
  cmd = _trim(cmd)
  if cmd == "" then return false end
  local Q = Yso.queue
  if Q and type(Q.bal_clear) == "function" then Q.bal_clear(cmd); return true end
  if Q and type(Q.push) == "function" then Q.push(cmd, "bal"); return true end
  if type(send) == "function" then send(cmd) end
  return true
end

local function _q_eq_clear(cmd)
  cmd = _trim(cmd)
  if cmd == "" then return false end
  local Q = Yso.queue
  if Q and type(Q.eq_clear) == "function" then Q.eq_clear(cmd); return true end
  if Q and type(Q.push) == "function" then Q.push(cmd, "eq"); return true end
  if type(send) == "function" then send(cmd) end
  return true
end

local function _q_class_clear(cmd)
  cmd = _trim(cmd)
  if cmd == "" then return false end

  -- Entity commands live on class/loyal balance, not EQ/BAL.
  if Yso and Yso.pulse and type(Yso.pulse.queue) == "function" then
    Yso.pulse.queue(cmd, { prefer = "eq" }) -- pulse classifies "order/command" and routes to class lane
    return true
  end

  local Q = Yso.queue
  if Q and type(Q.addclear) == "function" then Q.addclear("c!p!w!t", cmd); if Q.commit then Q.commit() end; return true end
  if Q and type(Q.class_clear) == "function" then Q.class_clear(cmd); return true end
  if Q and type(Q.push) == "function" then Q.push(cmd, "class"); return true end

  if type(send) == "function" then send(cmd) end
  return true
end

local function _tumble_guard_ok(tgt, window)
  window = tonumber(window) or 0.75
  tgt = _lc(tgt)
  if tgt == "" then return false end
  local st = C._st.tumble_react
  st.last = st.last or {}
  local now = _now()
  local last = tonumber(st.last[tgt] or 0) or 0
  if (now - last) < window then return false end
  st.last[tgt] = now
  return true
end

local function _react_tumble_begin(tgt, dir)
  if not _offense_active() then return end
  if not _tumble_guard_ok(tgt, 0.75) then return end

  local sm_ready = false
  if Yso and type(Yso.soulmaster_ready) == "function" then
    sm_ready = (Yso.soulmaster_ready() == true)
  else
    sm_ready = (rawget(_G, "soulmaster_ready") == true)
  end

  if not sm_ready then
    _hotpink(("%s TUMBLE BEGIN -> Lust (SM not ready)"):format(tgt))
    _q_bal_clear(("fling lust at %s"):format(tgt))
    return
  end

  local used_sm = false
  if Yso and Yso.occ and type(Yso.occ.sm_cmd_tumble) == "function" then
    local cmd = Yso.occ.sm_cmd_tumble(tgt, dir)
    cmd = _trim(cmd)
    if cmd ~= "" then
      used_sm = true
      _hotpink(("%s TUMBLE BEGIN -> Soulmaster dominate (anti-tumble)"):format(tgt))
      _q_eq_clear(cmd)
    end
  end

  if not used_sm then
    _hotpink(("%s TUMBLE BEGIN -> Lust (SM ready, no usable dominate)"):format(tgt))
    _q_bal_clear(("fling lust at %s"):format(tgt))
  end
end

local function _react_tumble_out(tgt, dir_upper)
  if not _offense_active() then return end
  _hotpink(("%s TUMBLED OUT TO THE %s!!! -> Empress"):format(tgt, dir_upper))
  _q_free("outd empress")
  _q_bal_clear(("fling empress %s"):format(tgt))
end

local function _react_leap_out(tgt, dir)
  if not _offense_active() then return end
  tgt = _trim(tgt)
  dir = _trim(dir)
  local diru = (dir ~= "" and tostring(dir):upper() or "?")
  _hotpink(("%s LEAPT OUT TO THE %s!!! -> Dop Lust + Empress"):format(tgt, diru))

  if type(Dop) == "table" and type(Dop.do_tarot_fling) == "function" then
    pcall(Dop.do_tarot_fling, "lust", tgt)
  end

  _q_free("outd lust")
  _q_free("outd empress")
  _q_bal_clear(("fling empress %s"):format(tgt))
end

function C.on_target_leap(tgt, dir)
  _react_leap_out(tgt or "", dir or "")
end

_pkill(killTrigger, C._tr.sluggish)
C._tr.sluggish = tempRegexTrigger([[^You move sluggishly into action\.$]], function()
  if type(Yso.note_sluggish) == "function" then Yso.note_sluggish("sluggish_line") end
end)

_pkill(killTrigger, C._tr.retardation)
C._tr.retardation = tempRegexTrigger([[time itself appears to slow\.?$]], function()
  if type(Yso.note_sluggish) == "function" then Yso.note_sluggish("retardation_line") end
end)

_pkill(killTrigger, C._tr.tumble_begin)
C._tr.tumble_begin = tempRegexTrigger([[^(\w+) begins to tumble towards the (\w+)\.$]], function()
  local tgt = matches[2] or ""
  local dir = matches[3] or ""

  if Yso and Yso.off and Yso.off.oc and Yso.off.oc.group_damage
     and type(Yso.off.oc.group_damage.mark_tumble) == "function" then
    Yso.off.oc.group_damage.mark_tumble(tgt, dir)
  elseif Yso and Yso.off and Yso.off.oc and Yso.off.oc.dmg
     and type(Yso.off.oc.dmg.mark_tumble) == "function" then
    Yso.off.oc.dmg.mark_tumble(tgt, dir)
  end

  if _gd_enabled() then return end

  _react_tumble_begin(tgt, dir)
end)

_pkill(killTrigger, C._tr.tumble_out)
C._tr.tumble_out = tempRegexTrigger([[^(\w+) tumbles out to the (\w+)\.$]], function()
  local tgt = matches[2] or ""
  local dir = tostring(matches[3] or ""):upper()

  local GD = _gd()
  if GD and type(GD.mark_tumble_out) == "function" then
    GD.mark_tumble_out(tgt, dir)
  end

  if _gd_enabled() then
    if _is_current(tgt) then _clear("tumble_out") end
    return
  end

  _react_tumble_out(tgt, dir)
  if _is_current(tgt) then _clear("tumble_out") end
end)

_pkill(killTrigger, C._tr.starburst)
C._tr.starburst = tempRegexTrigger([[^A starburst tattoo flares and bathes (\w+) in red light\.$]], function()
  local tgt = matches[2] or ""
  if _is_current(tgt) then
    _hotpink(("%s STARBURST RESET (continue offense)"):format(tgt))
    _cancel_dead_clear()
    _reset_enemy_state_on_starburst(tgt)
  end
end)

_pkill(killTrigger, C._tr.you_slain)
C._tr.you_slain = tempRegexTrigger([[^You have slain (\w+)\..*$]], function()
  local tgt = matches[2] or ""
  if _is_current(tgt) then
    _hotpink(("%s DEAD (you)"):format(tgt))
    _schedule_dead_clear(tgt)
  end
end)

_pkill(killTrigger, C._tr.other_slain)
C._tr.other_slain = tempRegexTrigger([[^(\w+) has been slain\b.*\.$]], function()
  local tgt = matches[2] or ""
  if _is_current(tgt) then
    _hotpink(("%s DEAD"):format(tgt))
    _schedule_dead_clear(tgt)
  end
end)

_pkill(killAnonymousEventHandler, C._ev.mode)
C._ev.mode = registerAnonymousEventHandler("yso.mode.changed", function(_, old, new, reason)
  new = tostring(new or ""):lower()
  if new ~= "hunt" then return end

  if Yso and Yso.off and Yso.off.oc then
    if Yso.off.oc.dmg and Yso.off.oc.dmg.state and Yso.off.oc.dmg.state.enabled
       and type(Yso.off.oc.dmg.stop) == "function" then
      Yso.off.oc.dmg.stop()
    end
    if Yso.off.oc.duel_limbs and Yso.off.oc.duel_limbs.state and Yso.off.oc.duel_limbs.state.enabled
       and type(Yso.off.oc.duel_limbs.stop) == "function" then
      Yso.off.oc.duel_limbs.stop()
    end
    if Yso.off.oc.enabled then
      Yso.off.oc.enabled = false
      if type(cecho) == "function" then cecho("<orange>[Yso:Occ] offense OFF (mode=hunt).\n") end
    end
  end
end)

_pkill(killAnonymousEventHandler, C._ev.rplayers)
C._ev.rplayers = registerAnonymousEventHandler("gmcp.Room.Players", function() _check_present("Room.Players") end)
_pkill(killAnonymousEventHandler, C._ev.rchars)
C._ev.rchars   = registerAnonymousEventHandler("gmcp.Room.Characters", function() _check_present("Room.Characters") end)

--========================================================--
