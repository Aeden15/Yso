-- Auto-exported from Mudlet package script: Api stuff
-- DO NOT EDIT IN XML; edit this file instead.

--========================
-- Namespace normalization (Yso/yso bridge)
-- Ensures BOTH _G.Yso and _G.yso exist and point to the same root table.
--========================
do
  local root = rawget(_G, "Yso")
  if type(root) ~= "table" then root = rawget(_G, "yso") end
  if type(root) ~= "table" then root = {} end
  _G.Yso = root
  _G.yso = root
  Yso = root
  yso = root
end

--========================================================--
-- Yso / Achaea Curing Core (Skeleton)
--  • No snd() usage, Achaea-only.
--  • Assumes: Legacy handles serverside CURING PRIORITY, etc.
--  • Assumes: AK1 + AK Tracker track ENEMY afflictions only.
--  • This file just defines the Yso.curing API and debug/status.
--========================================================--
setConsoleBufferSize("main", 300000, 1000)

Yso          = Yso or {}
Yso.affs     = Yso.affs or {}        -- our own afflictions (you can wire GMCP/text later)
Yso.curing   = Yso.curing or {}
Yso.ak       = Yso.ak or {}          -- forward declare so we can reference later if needed
Yso.cfg      = Yso.cfg or {}
-- Default command separator (Achaea CONFIG SEPARATOR) for all payload pipelines.
-- User preference: "&&" (override by setting Yso.cfg.pipe_sep before load).
Yso.cfg.pipe_sep = Yso.cfg.pipe_sep or "&&"
Yso.cfg.cmd_sep  = Yso.cfg.cmd_sep  or Yso.cfg.pipe_sep
Yso.sep      = Yso.sep or Yso.cfg.pipe_sep      -- used for multi-command sends


-- ----------------- tiny helpers (shared) -----------------
Yso.util = Yso.util or {}

function Yso.util.now()
  local v = (type(getEpoch)=="function" and tonumber(getEpoch())) or nil
  if v then
    if v > 1e12 then v = v / 1000 end
    return v
  end
  return os.time()
end

function Yso.util.echo(msg, color)
  if type(cecho) ~= "function" then return end
  local p = (Yso.cfg and Yso.cfg.echo_prefix) or "[Yso] "
  local c = color or "<cyan>"
  cecho(string.format("%s%s%s<reset>\n", p, c, tostring(msg)))
end

-- Single-tick scheduler guard (shared key across disk/mpackage)
Yso.util._tick_once_last = Yso.util._tick_once_last or {}
function Yso.util.tick_once(key, min_dt, fn, ...)
  key = tostring(key or "")
  if key == "" or type(fn) ~= "function" then return false, "badargs" end
  min_dt = tonumber(min_dt) or 0
  local now = Yso.util.now()
  local last = tonumber(Yso.util._tick_once_last[key] or 0) or 0
  if min_dt > 0 and (now - last) < min_dt then
    return false, "throttled"
  end
  Yso.util._tick_once_last[key] = now
  local ok, res = pcall(fn, ...)
  if not ok then
    Yso.util.echo("tick_once ERR: "..tostring(res), "<red>")
    return false, res
  end
  return true, res
end


-- ----------------- minimal locks (pending/backoff/cooldown hints) -----------------
-- NOTE: This is SSOT for lane readiness stability under GMCP lag.
Yso.locks = Yso.locks or {}
do
  local L = Yso.locks
  if L._yso_fulllocks ~= true and L._yso_minlocks ~= true then
    L._yso_minlocks = true
    L.cfg = L.cfg or { pending = 0.35 }
    L._lane = L._lane or {
      eq    = { pending_until = 0 },
      bal   = { pending_until = 0 },
      class = { pending_until = 0, backoff_until = 0 },
    }
    L._vitals = L._vitals or { eq = nil, bal = nil }

    local function _now() return (Yso.util and Yso.util.now and Yso.util.now()) or os.time() end

    function L.note_send(lane, pending)
      lane = tostring(lane or ""):lower()
      if lane == "ent" or lane == "entity" then lane = "class" end
      local st = L._lane[lane]; if not st then return end
      pending = tonumber(pending) or tonumber(L.cfg.pending) or 0.35
      st.pending_until = math.max(tonumber(st.pending_until or 0) or 0, _now() + pending)
    end

    function L.ent_backoff(seconds, src)
      seconds = tonumber(seconds) or 1.0
      if seconds <= 0 then seconds = 0.5 end
      local st = L._lane.class
      st.backoff_until = math.max(tonumber(st.backoff_until or 0) or 0, _now() + seconds)
      if Yso.state and type(Yso.state.set_ent_ready)=="function" then
        pcall(Yso.state.set_ent_ready, false, src or "locks.ent_backoff")
      end
    end

    function L.sync_vitals(v)
      v = v or (gmcp and gmcp.Char and gmcp.Char.Vitals) or {}
      local eq = tostring(v.eq or v.equilibrium or "") == "1" or (v.eq == true or v.equilibrium == true)
      local bal = tostring(v.bal or v.balance or "") == "1" or (v.bal == true or v.balance == true)
      if eq and L._vitals.eq == false and L._lane.eq then L._lane.eq.pending_until = 0 end
      if bal and L._vitals.bal == false and L._lane.bal then L._lane.bal.pending_until = 0 end
      L._vitals.eq, L._vitals.bal = eq, bal
    end

    function L.note_payload(payload)
      if type(payload) ~= "table" then return end
      if payload.eq then L.note_send("eq") end
      if payload.bal then L.note_send("bal") end
      if payload.class or payload.ent or payload.entity then
        L.note_send("class")
        if Yso.state and type(Yso.state.set_ent_ready)=="function" then
          pcall(Yso.state.set_ent_ready, false, "locks:payload")
        end
      end
    end

    function L.ready(lane)
      lane = tostring(lane or ""):lower()
      if lane == "ent" or lane == "entity" then lane = "class" end
      local st = L._lane[lane]
      local now = _now()
      if st and tonumber(st.pending_until or 0) > now then return false end
      if lane == "eq" then
        local v = nil

        if Yso.state and type(Yso.state.eq_ready)=="function" then

          local ok, r = pcall(Yso.state.eq_ready)

          if ok and r ~= nil then v = (r == true) end

        end

        if v ~= nil then return v end

        return true
      elseif lane == "bal" then
        local v = nil

        if Yso.state and type(Yso.state.bal_ready)=="function" then

          local ok, r = pcall(Yso.state.bal_ready)

          if ok and r ~= nil then v = (r == true) end

        end

        if v ~= nil then return v end

        return true
      elseif lane == "class" then
        if st and tonumber(st.backoff_until or 0) > now then return false end
        local v = nil

        if Yso.state and type(Yso.state.ent_ready)=="function" then

          local ok, r = pcall(Yso.state.ent_ready)

          if ok and r ~= nil then v = (r == true) end

        end

        if v ~= nil then return v end

        return true
      end
      return true
    end

    function L.eq_ready() return L.ready("eq") end
    function L.bal_ready() return L.ready("bal") end
    function L.ent_ready() return L.ready("class") end
  end
end

-- ----------------- trace ring (introspection) -----------------
Yso.trace = Yso.trace or {}
do
  local T = Yso.trace
  T.max = tonumber(T.max or 200) or 200
  T.buf = T.buf or {}
  T.idx = tonumber(T.idx or 0) or 0

  local function _push(entry)
    if type(entry) ~= "table" then entry = { msg = tostring(entry) } end
    entry.ts = entry.ts or (Yso.util and Yso.util.now and Yso.util.now()) or os.time()
    T.idx = (T.idx % T.max) + 1
    T.buf[T.idx] = entry
  end

  function T.push(kind, entry)
    entry = entry or {}
    entry.kind = kind or entry.kind or "log"
    _push(entry)
  end

  function T.dump(n)
    n = tonumber(n) or T.max
    if n <= 0 then return {} end
    local out = {}
    local count = math.min(n, #T.buf, T.max)
    local start = T.idx - count + 1
    for i = 0, count-1 do
      local j = start + i
      if j <= 0 then j = j + T.max end
      out[#out+1] = T.buf[j]
    end
    return out
  end

  function T.echo(n)
    local rows = T.dump(n)
    if type(cecho) ~= "function" then return rows end
    cecho("<dim_grey>[Yso.trace] last "..tostring(#rows).."\n")
    for i=1,#rows do
      local e = rows[i] or {}
      local ts = tostring(e.ts or "")
      local k  = tostring(e.kind or "")
      local r  = tostring(e.reason or e.src or e.msg or "")
      cecho(string.format("<dim_grey>  %s %-6s %s\n", ts, k, r))
    end
    return rows
  end
end




-- ----------------- global payload mode -----------------
Yso.cfg = Yso.cfg or {}
-- payload_mode: "paired" (combo) or "as_available" (freestyle)
Yso.cfg.payload_mode = Yso.cfg.payload_mode or "as_available"

function Yso.get_payload_mode()
  local m = tostring((Yso.cfg and Yso.cfg.payload_mode) or "as_available"):lower()
  if m == "freestyle" then m = "as_available" end
  if m == "combo" then m = "paired" end
  if m ~= "paired" and m ~= "as_available" then m = "as_available" end
  return m
end

function Yso.set_payload_mode(mode, quiet)
mode = tostring(mode or ""):lower()
if mode == "freestyle" then mode = "as_available" end
if mode == "combo" then mode = "paired" end
if mode ~= "paired" and mode ~= "as_available" then return false end

Yso.cfg = Yso.cfg or {}
Yso.cfg.payload_mode = mode

if not quiet and type(cecho) == "function" then
  local label = (mode == "paired") and "paired (combo)" or "as_available (freestyle)"
  cecho(string.format("<SlateBlue>[Occultism] <reset>Payload mode: <gold>%s<reset>\n", label))
end

if Yso.pulse and type(Yso.pulse.wake) == "function" then
  Yso.pulse.wake("payload_mode")
end
return true
end

-- ----------------- unified emitter (RAW, lane-aware) -----------------
Yso.lanes = Yso.lanes or {}
function Yso.lanes.normalize(lane)
  lane = tostring(lane or ""):lower()
  if lane == "ent" or lane == "entity" then return "class" end
  if lane == "pre" then return "free" end
  return lane
end

local function _has(v)
  if v == nil then return false end
  if type(v) == "string" then
    v = v:gsub("^%s+",""):gsub("%s+$","")
    return v ~= ""
  elseif type(v) == "table" then
    return v[1] ~= nil
  end
  return false
end

function Yso.emit(payload, opts)
  opts = opts or {}
  local Q = (Yso and Yso.queue)
  if not (Q and type(Q.stage)=="function" and type(Q.commit)=="function") then
    if Q and type(Q.emit)=="function" then
      return Q.emit(payload)
    end
    return false
  end

  if opts.solo == true and type(Q.clear)=="function" then
    Q.clear()
  end

  if type(payload) == "string" then
    if Yso.trace and type(Yso.trace.push)=="function" then
      Yso.trace.push("emit", { reason = opts.reason or opts.src or "raw", lanes = "raw" })
    end
    Q.stage("free", payload, opts)
    return Q.commit(opts)
  end

  if type(payload) == "table" and payload[1] ~= nil and payload.free == nil and payload.pre == nil and payload.eq == nil and payload.bal == nil and payload.class == nil and payload.ent == nil and payload.entity == nil then
    Q.stage("free", payload, opts)
    return Q.commit(opts)
  end

  if type(payload) ~= "table" then return false end

  if payload.free ~= nil then Q.stage("free", payload.free, opts) elseif payload.pre ~= nil then Q.stage("free", payload.pre, opts) end
  if payload.eq ~= nil then Q.stage("eq", payload.eq, opts) end
  if payload.bal ~= nil then Q.stage("bal", payload.bal, opts) end
  local cls = payload.class or payload.ent or payload.entity
  if cls ~= nil then Q.stage("class", cls, opts) end

  if Yso.trace and type(Yso.trace.push)=="function" then
    local lanes = {}
    local function _has(v)
      if v == nil then return false end
      if type(v) == "string" then
        v = v:gsub("^%s+",""):gsub("%s+$","")
        return v ~= ""
      elseif type(v) == "table" then
        return v[1] ~= nil
      end
      return false
    end
    if _has(payload.free) or _has(payload.pre) then lanes[#lanes+1] = "free" end
    if _has(payload.eq) then lanes[#lanes+1] = "eq" end
    if _has(payload.bal) then lanes[#lanes+1] = "bal" end
    if _has(cls) then lanes[#lanes+1] = "class" end
    Yso.trace.push("emit", { reason = opts.reason or opts.src, lanes = table.concat(lanes, ",") })
  end

  return Q.commit(opts)
end

-- ----------------- tiny helpers (CURING) -----------------
local function _cure_echo(msg)
  if Yso.curing.debug then
    cecho(string.format("<cyan>[Yso:Cure] <reset>%s\n", msg))
  end
end

local function _cure_warn(msg)
  cecho(string.format("<yellow>[Yso:Cure] <reset>%s\n", msg))
end

local function _cure_err(msg)
  cecho(string.format("<red>[Yso:Cure:ERR] <reset>%s\n", msg))
end

local function _send(cmd)
  if not cmd or cmd == "" then return end
  if type(send) == "function" then
    send(cmd, false)
  else
    _cure_err("send() not available to send: "..cmd)
  end
end


-- ----------------- config / adapters -----------------

-- Mode: "serverside" (default) or "manual"
Yso.curing.mode  = Yso.curing.mode or "serverside"
Yso.curing.debug = Yso.curing.debug or false

-- Adapters are where you wire to Legacy + game commands.
-- Override these in a separate file if you like.
Yso.curing.adapters = Yso.curing.adapters or {

  -- Toggle game-side CURING ON/OFF if you desire.
  game_curing_on = function()
    -- example:
    -- _send("CURING ON")
    _cure_echo("game_curing_on() called (adapter not yet wired)")
  end,

  game_curing_off = function()
    -- example:
    -- _send("CURING OFF")
    _cure_echo("game_curing_off() called (adapter not yet wired)")
  end,

  -- Legacy prio helpers: wire these to your real Legacy aliases/commands.
  raise_aff = function(aff)
    -- ex: _send(string.format("LEGACY PRIOUP %s", aff))
    _cure_echo(string.format("raise_aff(%s) called (adapter not yet wired)", tostring(aff)))
  end,

  lower_aff = function(aff)
    -- ex: _send(string.format("LEGACY PRIODOWN %s", aff))
    _cure_echo(string.format("lower_aff(%s) called (adapter not yet wired)", tostring(aff)))
  end,

  set_aff_prio = function(aff, prio)
    -- ex: _send(string.format("CURING PRIORITY %s %d", aff, prio))
    _cure_echo(string.format("set_aff_prio(%s, %s) called (adapter not yet wired)", tostring(aff), tostring(prio)))
  end,

  use_profile = function(name)
    -- ex: _send(string.format("LEGACY PROFILE %s", name))
    _cure_echo(string.format("use_profile(%s) called (adapter not yet wired)", tostring(name)))
  end,

  -- Optional “emergency” hooks, to be implemented as you decide.
  emergency = function(tag)
    -- ex: if tag == "lockpanic" then _send("LEGACY LOCKPANIC") end
    _cure_echo(string.format("emergency(%s) called (adapter not yet wired)", tostring(tag)))
  end,
}

-- shortcut
local C = Yso.curing.adapters

-- ----------------- public API: mode & toggles -----------------

function Yso.curing.set_mode(mode)
  mode = tostring(mode or ""):lower()
  if mode ~= "serverside" and mode ~= "manual" then
    _cure_warn("Invalid mode '"..mode.."'. Use 'serverside' or 'manual'.")
    return
  end
  Yso.curing.mode = mode
  _cure_echo("Mode set to "..mode)
end

function Yso.curing.toggle()
  if Yso.curing.mode == "serverside" then
    Yso.curing.set_mode("manual")
  else
    Yso.curing.set_mode("serverside")
  end
end

function Yso.curing.toggle_debug()
  Yso.curing.debug = not Yso.curing.debug
  _cure_echo("Debug is now "..(Yso.curing.debug and "ON" or "OFF"))
end

-- Optional helpers for explicit CURING ON/OFF via game.
function Yso.curing.game_curing_on()
  C.game_curing_on()
end

function Yso.curing.game_curing_off()
  C.game_curing_off()
end

-- ----------------- public API: priority & profiles -----------------

-- High-level wrappers: these are what offense/logic code should call.

function Yso.curing.raise_aff(aff)
  if not aff or aff == "" then return end
  C.raise_aff(aff)
end

function Yso.curing.lower_aff(aff)
  if not aff or aff == "" then return end
  C.lower_aff(aff)
end

function Yso.curing.set_aff_prio(aff, prio)
  if not aff or aff == "" then return end
  prio = tonumber(prio)
  if not prio then
    _cure_warn("set_aff_prio("..tostring(aff)..", ?) called with invalid priority")
    return
  end
  C.set_aff_prio(aff, prio)
end

function Yso.curing.use_profile(name)
  if not name or name == "" then return end
  C.use_profile(name)
end

-- Emergency entry point. “tag” is free-form, e.g. "lockpanic", "damagepanic".
function Yso.curing.emergency(tag)
  if not tag or tag == "" then return end
  C.emergency(tag)
end

-- ----------------- status & diagnostics -----------------

local function _curing_on_off()
  -- stub; if you later parse game CURING status, return "ON"/"OFF" here.
  return "unknown"
end

local function _legacy_profile()
  -- stub; if Legacy exposes current profile, return it here.
  return "unknown"
end

function Yso.curing.status()
  cecho("<green>[Yso:Cure Status]\n")
  cecho(string.format("  Mode:         <white>%s\n", Yso.curing.mode))
  cecho(string.format("  Debug:        <white>%s\n", Yso.curing.debug and "ON" or "OFF"))
  cecho(string.format("  Game CURING:  <white>%s\n", _curing_on_off()))
  cecho(string.format("  Legacy set:   <white>%s\n", _legacy_profile()))
  -- If you expose AK Tracker state, you can echo it here:
  -- cecho(string.format("  AK Tracker:   <white>%s\n", Yso.ak and Yso.ak.ready and "READY" or "n/a"))
end

-- ----------------- init helper -----------------

function Yso.curing.init()
  _cure_echo("Yso.curing core skeleton initialised.")
  -- If needed, you can call this once from your startup scripts.
end

-- Auto-init on load (if you prefer passive behaviour)
Yso.curing.init()

--========================================================--
-- End of Yso / Achaea Curing Core (Skeleton)
--========================================================--


--========================================================--
-- Yso / Achaea AK Wrapper (Enemy Aff Tracker Skeleton)
--  • Wraps AK1 / AK Tracker under Yso.ak namespace.
--  • Does NOT replace AK – it just mirrors/normalizes it.
--  • Other code should ONLY talk to Yso.ak, never raw AK.
--========================================================--

Yso.ak         = Yso.ak or {}
Yso.ak.enemy   = Yso.ak.enemy or {
  name      = "",        -- current tracked enemy (string)
  affs      = {},        -- [aff_name] = true
  last_gain = {},        -- [aff_name] = timestamp
  last_cure = {},        -- [aff_name] = timestamp
}
Yso.ak.debug     = Yso.ak.debug or false
Yso.ak.threshold = Yso.ak.threshold or 100   -- used later for embellished status / bridge

-- ----------------- tiny helpers (AK) -----------------
local function _ak_now()
  if type(getEpoch) == "function" then return getEpoch() end
  return os.time()
end

local function _ak_echo(msg)
  if Yso.ak.debug then
    cecho(string.format("<magenta>[Yso:AK] <reset>%s\n", msg))
  end
end

local function _ak_warn(msg)
  cecho(string.format("<yellow>[Yso:AK] <reset>%s\n", msg))
end

local function _ak_trim(s)
  s = tostring(s or "")
  s = s:gsub("^%s+", ""):gsub("%s+$", "")
  -- Strip Mudlet auto-complete tags like " (player)" / " (npc)" at end
  s = s:gsub("%s*%b()%s*$", "")
  s = s:gsub("^%s+", ""):gsub("%s+$", "")
  -- Player names are single-token; if junk remains, keep first token
  s = s:match("^(%S+)") or s
  return s
end

-- ----------------- adapters (to AK Tracker) -----------------
-- You wire these to your real AK Tracker implementation.
-- For example: pull AK's aff table, or hook AK's callbacks into gain/cure.
Yso.ak.adapters = Yso.ak.adapters or {

  -- Return a table of current enemy affs from AK:
  --   { paralysis = true, asthma = true, ... }
  pull_full_state = function()
    -- Example (pseudocode, replace with real AK access):
    -- return table.copy(AK.enemy.affs)
    _ak_echo("adapters.pull_full_state() called (not wired)")
    return nil
  end,

  -- Optional: let AK know when we change target.
  on_target_change = function(name)
    -- Example:
    -- AK.setTarget(name)
    _ak_echo(string.format("adapters.on_target_change(%s) called (not wired)", tostring(name)))
  end,
}

local AK = Yso.ak.adapters

-- ----------------- core state API -----------------

function Yso.ak.set_target(name, opts)
  name = _ak_trim(name)
  if name == "" then
    _ak_warn("set_target() called with empty name; keeping current enemy.")
    return
  end

  opts = opts or {}
  local reset = opts.reset ~= false  -- default true

  if Yso.ak.enemy.name ~= name and reset then
    Yso.ak.enemy.affs      = {}
    Yso.ak.enemy.last_gain = {}
    Yso.ak.enemy.last_cure = {}
    _ak_echo("Target changed; enemy affs reset.")
  end

  Yso.ak.enemy.name = name
  _ak_echo("Tracking enemy: "..name)

  -- Notify AK if desired.
  AK.on_target_change(name)
end

-- Called by your AK Tracker when it believes enemy gains an aff.
-- You can hook this in directly from AK1/Tracker logic.
function Yso.ak.gain(aff, meta)
  if not aff or aff == "" then return end
  aff = tostring(aff):lower()

  Yso.ak.enemy.affs[aff]      = true
  Yso.ak.enemy.last_gain[aff] = _ak_now()

  if meta and meta.source then
    _ak_echo(string.format("GAIN %s (%s)", aff, meta.source))
  else
    _ak_echo("GAIN "..aff)
  end
end

-- Called by your AK Tracker when it believes enemy cures an aff.
function Yso.ak.cure(aff, meta)
  if not aff or aff == "" then return end
  aff = tostring(aff):lower()

  if Yso.ak.enemy.affs[aff] then
    Yso.ak.enemy.affs[aff]      = nil
    Yso.ak.enemy.last_cure[aff] = _ak_now()

    if meta and meta.source then
      _ak_echo(string.format("CURE %s (%s)", aff, meta.source))
    else
      _ak_echo("CURE "..aff)
    end
  end
end

-- Full sync from AK Tracker (e.g. on target swap, or periodic recalc)
function Yso.ak.sync_from_ak()
  local state = AK.pull_full_state()
  if not state or type(state) ~= "table" then
    _ak_warn("sync_from_ak(): adapter returned no state.")
    return
  end

  Yso.ak.enemy.affs = {}
  for aff, present in pairs(state) do
    if present then
      aff = tostring(aff):lower()
      Yso.ak.enemy.affs[aff]      = true
      Yso.ak.enemy.last_gain[aff] = Yso.ak.enemy.last_gain[aff] or _ak_now()
    end
  end

  _ak_echo("Enemy affs synced from AK.")
end

-- ----------------- query helpers -----------------

-- Basic “does enemy have X?”
function Yso.ak.has(aff)
  if not aff or aff == "" then return false end
  aff = tostring(aff):lower()
  return Yso.ak.enemy.affs[aff] and true or false
end

-- Count how many of a list enemy has.
-- affs can be { "asthma", "paralysis" } or "asthma/paralysis/...".
function Yso.ak.count(affs)
  if not affs then return 0 end
  local list = {}

  if type(affs) == "string" then
    for part in affs:gmatch("([^/]+)") do
      list[#list+1] = part:lower()
    end
  elseif type(affs) == "table" then
    for _,a in ipairs(affs) do list[#list+1] = tostring(a):lower() end
  else
    return 0
  end

  local n = 0
  for _,a in ipairs(list) do
    if Yso.ak.enemy.affs[a] then n = n + 1 end
  end
  return n
end

-- “Does enemy have at least N of these affs?”
function Yso.ak.any(affs, n)
  n = tonumber(n) or 1
  if n <= 0 then return true end
  return Yso.ak.count(affs) >= n
end

-- Returns a sorted list of current aff names.
function Yso.ak.list_affs()
  local out = {}
  for a,_ in pairs(Yso.ak.enemy.affs) do
    out[#out+1] = a
  end
  table.sort(out)
  return out
end

-- ----------------- status / debug (embellished) -----------------

function Yso.ak.status()
  Yso.ak.enemy = Yso.ak.enemy or { name = "", affs = {} }
  local target = Yso.ak.enemy.name or ""
  if target == "" then target = "(none)" end

  local list      = Yso.ak.list_affs()
  local total     = #list
  local max_show  = 10
  local threshold = Yso.ak.threshold or 100

  cecho("<magenta>[Yso:AK Status]\n")
  cecho(string.format("  Target:     <white>%s\n", target))
  cecho(string.format("  Debug:      <white>%s\n", Yso.ak.debug and "ON" or "OFF"))
  cecho(string.format("  Threshold:  <white>%d\n", threshold))
  cecho(string.format("  AK affs:    <white>%d\n", total))

  if total == 0 then
    cecho("  Affs list:  <white>none\n")
  else
    local shown = {}
    for i = 1, math.min(total, max_show) do
      shown[#shown+1] = list[i]
    end
    local extra = total - #shown

    if extra > 0 then
      cecho(string.format(
        "  Affs list:  <white>%s<reset> <gray>(+%d more)\n",
        table.concat(shown, ", "),
        extra
      ))
    else
      cecho("  Affs list:  <white>"..table.concat(shown, ", ").."\n")
    end
  end
end

function Yso.ak.toggle_debug()
  Yso.ak.debug = not Yso.ak.debug
  _ak_echo("Debug is now "..(Yso.ak.debug and "ON" or "OFF"))
end

-- ----------------- init -----------------

function Yso.ak.init()
  _ak_echo("Yso.ak core skeleton initialised.")
end

Yso.ak.init()

--========================================================--
-- End of Yso / Achaea AK Wrapper (Skeleton)
--========================================================--


--========================================================--
-- Self-aff helpers (used by offense + queue guards)
--========================================================--

Yso      = Yso or {}
Yso.self = Yso.self or {}

function Yso.self.has_aff(aff)
  local key = tostring(aff or ""):lower()
  if key == "" then return false end

  -- Preferred: Legacy curing table (self affs)
  if Legacy and Legacy.Curing and type(Legacy.Curing.Affs) == "table" then
    if Legacy.Curing.Affs[key] then return true end
    -- Some tables keep TitleCase keys
    local tc = key:gsub("^%l", string.upper)
    if Legacy.Curing.Affs[tc] then return true end
  end

  -- Fallback: GMCP aff list shapes (varies by client/package)
  local g = gmcp and gmcp.Char and gmcp.Char.Afflictions
  if type(g) == "table" then
    -- common list fields
    local candidates = { g.list, g.List, g.afflictions, g.Afflictions }
    for _, lst in ipairs(candidates) do
      if type(lst) == "table" then
        for _, v in ipairs(lst) do
          if type(v) == "string" and v:lower() == key then return true end
          if type(v) == "table" and v.name and tostring(v.name):lower() == key then return true end
        end
      end
    end
    -- occasionally boolean keyed
    if g[key] == true then return true end
  end

  return false
end

function Yso.self.is_paralyzed()
  return Yso.self.has_aff("paralysis")
end
