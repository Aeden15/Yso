-- Auto-exported from Mudlet package script: Yso.pulse (wake bus)
-- DO NOT EDIT IN XML; edit this file instead.

--========================================================--
-- Yso.pulse (wake/tick bus) — PURE DISPATCHER
--========================================================--
-- What this is:
--   A centralized wake bus that simply *dispatches* work once per tick.
--   It does NOT maintain an independent readiness model.
--
-- What this is NOT:
--   No per-lane ready/pending state machine in the bus.
--   Readiness/backoff live in Yso.state / Yso.locks.
--   Emission lives in Yso.emit() / Yso.queue (RAW sendAll/send).
--
-- Key guarantee:
--   Dispatch is guarded by Yso.util.tick_once("yso.tick", 0.05, fn)
--   so disk pulse + mpackage wake sources cannot double-tick.
--========================================================--

Yso = Yso or {}
Yso.pulse = Yso.pulse or {}

local P = Yso.pulse
P.cfg = P.cfg or {
  debounce = 0.05,
  debug = false,

  -- Legacy qtype strings are retained for compatibility with callers that still
  -- pass them into Yso.queue.stage()/addclear(). They no longer represent
  -- server-side QUEUE usage.
  q_eq    = "e!p!w!t",
  q_bal   = "b!p!w!t",
  q_class = "c!p!w!t",
  q_free  = "free",

  replace_when_pending = true,
}

P.state = P.state or {
  reg = {},
  reg_order = {},
  reasons = {},
  _debounce_timer = nil,
  _in_flush = false,
  _did_emit = false, -- used by orchestrator/exclusive callbacks
  _eh_vitals = nil,
  _eh_prompt = nil,
}

local function _dbg(msg)
  if P.cfg.debug then cecho("<gray>[pulse] "..tostring(msg).."\n") end
end

local function _trim(s)
  s = tostring(s or "")
  s = s:gsub("^%s+",""):gsub("%s+$","")
  return s
end

local function _resort()
  local tmp = {}
  for name, r in pairs(P.state.reg) do
    tmp[#tmp+1] = { name = name, order = tonumber(r.order) or 50 }
  end
  table.sort(tmp, function(a,b)
    if a.order == b.order then return a.name < b.name end
    return a.order < b.order
  end)
  P.state.reg_order = tmp
end

function P.debug(on)
  P.cfg.debug = (on == true)
  _dbg("debug="..tostring(P.cfg.debug))
end

function P.register(name, fn, opts)
  name = tostring(name or "")
  if name == "" or type(fn) ~= "function" then return end
  opts = opts or {}
  P.state.reg[name] = {
    fn = fn,
    order = tonumber(opts.order) or 50,
    enabled = (opts.enabled ~= false),
  }
  _resort()
end

function P.enable(name, on)
  local r = P.state.reg[name]
  if not r then return end
  r.enabled = (on == true)
  P.wake("enable:"..tostring(name))
end

function P.wake(reason)
  reason = tostring(reason or "wake")
  P.state.reasons[reason] = true

  if P.state._debounce_timer then return end
  P.state._debounce_timer = tempTimer(P.cfg.debounce or 0.05, function()
    P.state._debounce_timer = nil
    P.flush()
  end)
end

P.bump = P.wake

-- ---------------- compatibility adapters (NOT a readiness model) ----------------
-- Some triggers/modules still call pulse.set_ready()/is_ready().
-- We forward to canonical Yso.state readiness helpers.
local function _lane_key(lane)
  lane = tostring(lane or ""):lower()
  if lane == "ent" or lane == "entity" then return "class" end
  return lane
end

function P.set_ready(lane, ready, src)
  lane = _lane_key(lane)
  ready = (ready == true)
  src = tostring(src or "pulse:set_ready")

  -- Only entity/class has a canonical settable readiness.
  if lane == "class" and Yso.state and type(Yso.state.set_ent_ready) == "function" then
    pcall(Yso.state.set_ent_ready, ready, src)
  end

  -- Always wake so handlers can re-evaluate.
  P.wake(src)
end

function P.is_ready(lane)
  lane = _lane_key(lane)
  if lane == "eq" and Yso.state and type(Yso.state.eq_ready)=="function" then
    local ok,v = pcall(Yso.state.eq_ready); if ok then return v==true end
  elseif lane == "bal" and Yso.state and type(Yso.state.bal_ready)=="function" then
    local ok,v = pcall(Yso.state.bal_ready); if ok then return v==true end
  elseif lane == "class" and Yso.state and type(Yso.state.ent_ready)=="function" then
    local ok,v = pcall(Yso.state.ent_ready); if ok then return v==true end
  end
  return true
end

-- Optional ack hook for entity command outcomes.
function P.entity_ack(kind, src)
  kind = tostring(kind or ""):lower()
  src = tostring(src or "entity_ack")

  local function _now()
    if Yso and Yso.util and type(Yso.util.now) == "function" then
      local ok,v = pcall(Yso.util.now)
      v = ok and tonumber(v) or nil
      if v then return v end
    end
    local v = (type(getEpoch) == "function" and tonumber(getEpoch())) or nil
    if v then
      if v > 1e12 then v = v / 1000 end
      return v
    end
    return os.time()
  end

  local function _restage_last_ent(reason)
    local Y = rawget(_G, "Yso")
    if not (Y and Y.state and Y.queue and type(Y.queue.stage) == "function") then return end
    local cmd = Y.state._last_ent_cmd
    local ts  = Y.state._last_ent_cmd_ts
    if type(cmd) ~= "string" or cmd == "" then return end
    if ts ~= nil and (_now() - ts) > 3.0 then return end
    if Y.queue._staged and Y.queue._staged.class ~= nil then return end
    pcall(Y.queue.stage, "class", cmd, { src = reason or "entity_ack" })
  end

  if kind == "fail" or kind == "cooldown" then
    _restage_last_ent(src..":"..kind)
    local cd = (Yso and Yso.state and tonumber(Yso.state._ent_last_cmd_cd)) or nil
    local backoff
    if kind == "cooldown" then backoff = cd or 1.25 else backoff = 0.85 end
    if Yso.state and type(Yso.state.ent_fail)=="function" then
      pcall(Yso.state.ent_fail, backoff, src)
    elseif Yso.state and type(Yso.state.set_ent_ready)=="function" then
      pcall(Yso.state.set_ent_ready, false, src)
    end
    P.wake(src)
  elseif kind == "sent" then
    if Yso.state and type(Yso.state.set_ent_ready)=="function" then
      pcall(Yso.state.set_ent_ready, false, src)
    end
  end
end



-- ---------------- failsafe text triggers (disk workspace) ----------------
-- These are defensive duplicates of the XML triggers. They ensure the entity lane
-- can recover even if a trigger export/import drifts.
P._trig = P._trig or {}
local function _kill_trig(id)
  if id and type(killTrigger) == "function" then killTrigger(id) end
end

if type(tempRegexTrigger) == "function" then
  -- Entity ready line
  _kill_trig(P._trig.entity_ready_failsafe)
  P._trig.entity_ready_failsafe = tempRegexTrigger(
    [[^You may command another entity to do your bidding\.$]],
    function()
      if Yso and Yso.occ then Yso.occ.entity_ready = true end
      P.set_ready("entity", true, "line:entity_ready")
    end
  )


  -- Entity cooldown line
  _kill_trig(P._trig.entity_too_soon_failsafe)
  P._trig.entity_too_soon_failsafe = tempRegexTrigger(
    [[^You may not command another entity so soon\.$]],
    function()
      if Yso and Yso.occ then Yso.occ.entity_ready = false end
      P.set_ready("entity", false, "line:entity_too_soon")
      P.entity_ack("cooldown", "line:entity_too_soon")
    end
  )
  -- Disregard line: apply short backoff + timed recovery
  _kill_trig(P._trig.entity_disregard_failsafe)
  P._trig.entity_disregard_failsafe = tempRegexTrigger(
    [[^(?:A|The) .+ disregards your order\.$]],
    function()
      if Yso and Yso.occ then Yso.occ.entity_ready = false end
      P.set_ready("entity", false, "line:entity_disregard")
      P.entity_ack("fail", "line:entity_disregard")
      if type(tempTimer) == "function" then
        tempTimer(2.75, function()
          if Yso and Yso.occ then Yso.occ.entity_ready = true end
        end)
      end
    end
  )
end

-- Payload convenience: split by pipe separator and classify into lanes.
-- This is only a compatibility helper for older modules; preferred approach is
-- to call Yso.emit({eq=..., bal=..., class=..., free=...}).
local function _is_free(c)
  local lc = c:lower()
  return lc == "stand"
      or lc:match("^writhe%s+")
      or lc:match("^contemplate%s+")
      or lc:match("^order%s+")
end
local function _is_entity(c)
  local lc = c:lower()
  if not lc:match("^command%s+") then return false end
  -- Gremlin/soulmaster are EQ-lane despite the "command" verb.
  if lc:match("^command%s+gremlin%s+") or lc:match("^command%s+soulmaster%s+") then return false end
  return true
end
local function _is_bal_main(c)
  local lc = c:lower()
  return lc:match("^fling%s+")
      or lc:match("^flick%s+")
      or lc:match("^toss%s+")
      or lc:match("^ruinate%s+")
      or lc:match("^throw%s+")
      or lc:match("^wipe%s+")
      or lc:match("^envenom%s+")
end

local function _emit(payload, opts)
  if type(Yso.emit) == "function" then
    local ok = Yso.emit(payload, opts)
    if ok then P.state._did_emit = true end
    return ok
  end
  -- Fallback: route to raw queue emitter.
  if Yso.queue and type(Yso.queue.emit)=="function" then
    local ok = pcall(Yso.queue.emit, payload)
    if ok then P.state._did_emit = true end
    return ok
  end
  return false
end

function P.send_free(cmd, opts)   return _emit({ free = cmd }, opts or { reason = "pulse.send_free" }) end
function P.send_eq(cmd, opts)     return _emit({ eq = cmd },   opts or { reason = "pulse.send_eq", prefer = "eq" }) end
function P.send_bal(cmd, opts)    return _emit({ bal = cmd },  opts or { reason = "pulse.send_bal", prefer = "bal" }) end
function P.send_entity(cmd, opts) return _emit({ class = cmd }, opts or { reason = "pulse.send_entity" }) end

function P.queue(payload, opts)
  payload = _trim(payload)
  if payload == "" then return false end

  local sep = (Yso and Yso.cfg and Yso.cfg.pipe_sep) or (Yso and Yso.sep) or "&&"
  local parts = {}

  -- Split on separator (plain find; safe for any separator string)
  local i = 1
  while true do
    local a,b = payload:find(sep, i, true)
    if not a then
      local chunk = _trim(payload:sub(i))
      if chunk ~= "" then parts[#parts+1] = chunk end
      break
    end
    local chunk = _trim(payload:sub(i, a-1))
    if chunk ~= "" then parts[#parts+1] = chunk end
    i = b + 1
  end

  local free = {}
  local ent, eq, bal = nil, nil, nil

  local prefer = opts and tostring(opts.prefer or ""):lower() or ""
  if prefer ~= "bal" then prefer = "eq" end

  for _,c in ipairs(parts) do
    local lc = c:lower()
    if lc:match("^command%s+gremlin%s+") then
      -- Gremlin shieldbreak is EQ-solo. Do not attach anything.
      return P.send_eq(c, { solo=true, prefer="eq", reason="pulse.queue:gremlin" })
    elseif lc:match("^command%s+soulmaster%s+") or lc:match("^order%s+soulmaster%s+") then
      -- Soulmaster commands are EQUILIBRIUM-based in Achaea; treat as EQ-solo.
      return P.send_eq(c, { solo=true, prefer="eq", reason="pulse.queue:soulmaster" })
    elseif _is_free(c) then
      free[#free+1] = c
    elseif _is_entity(c) then
      ent = ent or c
    else
      if _is_bal_main(c) then
        bal = bal or c
      else
        eq = eq or c
      end
    end
  end

  -- Never EQ+BAL together unless explicitly allowed.
  if eq and bal and not (opts and opts.allow_eqbal == true) then
    if prefer == "bal" then eq = nil else bal = nil end
  end

  return _emit({ free = free, class = ent, eq = eq, bal = bal }, opts or { reason = "pulse.queue" })
end

-- ---------------- dispatch loop ----------------
function P._flush_inner()
  if P.state._in_flush then return end
  P.state._in_flush = true
  P.state._did_emit = false

  local reasons = {}
  for k,_ in pairs(P.state.reasons) do reasons[#reasons+1] = k end
  table.sort(reasons)
  P.state.reasons = {}

  if P.cfg.debug and #reasons > 0 then
    _dbg("wake: "..table.concat(reasons, ", "))
  end

  for _,row in ipairs(P.state.reg_order) do
    local r = P.state.reg[row.name]
    if r and r.enabled and type(r.fn)=="function" then
      local ok, err = pcall(r.fn, reasons)
      if not ok then _dbg("ERR "..row.name..": "..tostring(err)) end
      if P.state._did_emit then break end
    end
  end

  P.state._in_flush = false
end

function P.flush()
  if Yso.util and type(Yso.util.tick_once) == "function" then
    local ok, res = Yso.util.tick_once("yso.tick", 0.05, P._flush_inner)
    return res
  end
  return P._flush_inner()
end

-- GMCP wake: mirror vitals into Yso.state via ingest, then wake.
local function _on_vitals()
  local v = (gmcp and gmcp.Char and gmcp.Char.Vitals) or {}

  if Yso and Yso.ingest and type(Yso.ingest.vitals) == "function" then
    pcall(Yso.ingest.vitals, v, "gmcp")
  end

  if Yso and Yso.locks and type(Yso.locks.sync_vitals) == "function" then
    pcall(Yso.locks.sync_vitals, v)
  end

  P.wake("gmcp:vitals")
end

if P.state._eh_vitals then pcall(killAnonymousEventHandler, P.state._eh_vitals) end
P.state._eh_vitals = registerAnonymousEventHandler("gmcp.Char.Vitals", _on_vitals)

-- Prompt wake fallback: prevents "sleep" if GMCP/line triggers are missed.
local function _on_prompt()
  P.wake("prompt")
end
if P.state._eh_prompt then pcall(killAnonymousEventHandler, P.state._eh_prompt) end
P.state._eh_prompt = registerAnonymousEventHandler("sysPrompt", _on_prompt)

_dbg("pulse bus loaded (dispatcher-only)")
--========================================================--


-- ---------------- compatibility shims ----------------
-- Some older disk-based modules call kick()/stop()/unregister(); keep them working.
if type(P.kick) ~= "function" then
  function P.kick(reason) return P.wake(reason or "kick") end
end

if type(P.unregister) ~= "function" then
  function P.unregister(name)
    name = tostring(name or "")
    if name == "" then return end
    P.state.reg[name] = nil
    _resort()
  end
end

if type(P.stop) ~= "function" then
  function P.stop()
    -- Disable every registered handler and cancel any pending debounce flush.
    for _, r in pairs(P.state.reg or {}) do
      if type(r) == "table" then r.enabled = false end
    end
    if P.state._debounce_timer and type(killTimer) == "function" then
      pcall(killTimer, P.state._debounce_timer)
    end
    P.state._debounce_timer = nil
    P.state.reasons = {}
  end
end

-- If the disk-based init.lua boot already ran before this bus loaded, wake once.
do
  local root = rawget(_G, "Yso")
  if type(root) == "table" and type(root._boot) == "table" and root._boot.loaded == true then
    P.wake("boot")
  end
end
