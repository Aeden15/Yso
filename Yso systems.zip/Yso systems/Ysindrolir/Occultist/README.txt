Update (2026-02-28) — DRY-run lane lab: no ENT spend / no lock mutation
-----------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- DRY-run correctness: when Yso.net.cfg.dry_run == true,
  • Yso.queue.commit() no longer calls Yso.locks.note_payload/note_send (prevents ENT from flipping DOWN during lane lab).
  • Yso.queue.emit() no longer hard-spends ENT (set_ent_ready(false)) during DRY.
  • Yso.net.emit_payload() no longer flips ENT DOWN during DRY.
Result:
- Devtools “Lane Lab” tests match expectation: lanes only change when you explicitly toggle them (ylane ...), not because a DRY commit mutated state.


Update (2026-02-28) — Devtools alias fix + entity lane re-stage + qtype mapping + bootstrap non-clobber
---------------------------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- Devtools: ^yreload/^yinit no longer dofile() a dead hardcoded path (C:\Achaea\Occultist\lua\init.lua).
  • yreload now prefers Yso.reload() when available; otherwise it attempts a disk bootstrap load from the workspace root.
- Queue lane mapping: legacy qtype strings no longer mis-route BAL into EQ.
  • "ebc!p!w!t" => bal, "ec!p!w!t" => eq.
- Entity lane: on "disregards your order" / cooldown-fail, the last entity COMMAND is re-staged (best-effort) so pressure isn't lost.
- Payload classifier: ORDER is treated as FREE lane (not entity lane), and COMMAND gremlin/soulmaster are excluded from entity spend.
- Bootstrap: secondary bootstrap no longer clobbers package.path; it now guards on _G.yso_bootstrap_done and prepends patterns.
- Integration.mudlet: RELEASE installs (mpackage-only) no longer error; Integration.mudlet is provided via package.preload fallback.


Update (2026-02-28): wrappers fixed + use Yso_FIXED.mpackage.

    Yso Occultist Modules Bundle
    ===========================


Update (2026-02-27) — Entity lane hardening (no-more "disregard" deadlock)
-----------------------------------------------------------------------
- SSOT entity lane now has timed recovery on send/fail:
  • Added Yso.state.ent_busy(seconds) which schedules a recovery timer.
  • Yso.locks.note_payload() detects COMMAND <entity> and applies per-entity cooldowns.
  • Prevents stalls when "You may command another entity..." is missed or when a disregard flips flags.
- Yso.pulse.entity_ack("sent") now calls P.wake() (prevents silent stall if ready line is missed).
- ORDER <minion> is no longer treated as an entity-balance lane action in pulse pipeline parsing.
- Added disk-level failsafe triggers for:
  • "You may command another entity to do your bidding." (sets entity lane ready)
  • "<entity> disregards your order." (sets short backoff + timed recovery)
- Skill chart update:
  • Added missing Lycantha (Hound) AB id + cooldown (2.20s entity).

    Intended install location (matches your Mudlet bootstrap):
      C:\Achaea\Yso\modules\

    This zip contains:
      - Integration/mudlet.lua  (Mudlet trigger bridge: require("Integration.mudlet"))
      - Yso/_entry.lua          (disk-workspace loader; loads Yso/xml/*.lua in order)
      - Yso/xml/*               (canonical scripts you should edit)

    Wrapper modules (compat shims):
      - The tiny modules under Yso/ (Core/*, Combat/*, etc.) are convenience shims.
      - These were previously corrupted (self-require recursion). They are now fixed to:
          • require("Yso") (loads _entry)
          • return the best-effort canonical namespace (or Yso)

    Mudlet import:
      - Import Yso_FIXED.mpackage (included at ZIP root).
      - The older Yso.mpackage could import “missing scripts” due to XML corruption.

    Mudlet Bootstrap snippet (paste into a Mudlet script):

      _G.yso_default_package_path = _G.yso_default_package_path or package.path
      local root = "C:/Achaea/Yso/modules"
      root = tostring(root):gsub("\\","/"):gsub("/+$","")
      if not package.path:find(root .. "/?.lua", 1, true) then
        package.path = (root .. "/?.lua") .. ";" .. package.path
      end
      if not package.path:find(root .. "/?/init.lua", 1, true) then
        package.path = (root .. "/?/init.lua") .. ";" .. package.path
      end

    Quick test (Mudlet input line):
      lua pcall(require, "Integration.mudlet")
      lua pcall(require, "Yso")
      lua pcall(require, "Combat.offense_core")
========================================
CLEANUP + BUGFIXES APPLIED (2026-02-23 10:02Z)
- Fixed Q._stage -> Q._staged (_queue_has_staged)
- Added Q.clear(lane) if missing
- api_stuff cmd_sep default -> && (via pipe_sep)
- softlock_gate legacy qtype 'ebc!p!w!t!' -> 'eq'
- yso_queue autocommit forced false (if present)
- bootstrap auto_roots loop no longer capped at 3 (best-effort)
- Deleted: duel_limbs / unravel_* / duplicates / desktop.ini / Bug fixes.pdf (inside archive)
================================================================================
PARTY MODE + GROUP DAMAGE PATCH (2026-02-24)
- Added new Yso.mode "party" with subroutes: party aff / party dam
  • Includes tempAlias support: mode / mode <hunt|combat|party> / party [aff|dam] / partyroute <aff|dam>
  • Party route "dam" auto-starts group_damage driver (Yso.off.oc.dmg or Yso.off.oc.group_damage)
  • Party route "aff" placeholder (driver not implemented yet)
  • Leaving party mode stops ONLY the group_damage driver started by party (ownership tracking)
- Mode autoswitch now RESPECTS party mode (will not flip you hunt/combat while party is active)
- Pipeline separator policy updated:
  • Default separator is "&&" (Achaea CONFIG SEPARATOR)
  • Yso.net/Yso.queue now allow "&&" as a valid separator (in addition to "|" and ";;")
- group_damage send path refactored:
  • Lane-aware emission (free/eq/class/bal) with readiness gating (Yso.locks/Yso.state)
  • No server-side QUEUE commands; emits via Yso.emit/Yso.queue.emit
- Duplicates removed from workspace zip:
  • Deleted nested duplicate tree: "Yso systems/Yso systems/..."
  • Deleted: desktop.ini
========================================

========================================
ENTITY LANE BOOTSTRAP + PAIRED FALLBACK (2026-02-26)
- Entity readiness no longer gets stuck false across reloads:
  • If GMCP charstats shows 'Entity: Yes' and there is no active backoff,
    Yso.state.ent_ready() will bootstrap to true when stale.
- Payload mode 'paired' no longer hard-stalls when entity lane is down:
  • commit() will still allow EQ/BAL to drip while waiting for ENTITY to recover
    (ENTITY will not be emitted solo from the paired-branch).
- Group damage driver updated to match the above semantics:
  • Tries to include ENTITY in opener/setup, but does not stall if entity is down.
========================================

========================================
GROUP DAMAGE AUTOMATION FIXES (2026-02-26)
- Fixed fatal XML-export escape bug in yso_queue.lua (\" tokens) that prevented Yso.queue/Yso.net from loading.
- group_damage now performs lazy pulse registration on enable (fixes load-order skips).
- group_damage registers at pulse order=0 so it is not starved by orchestrator (order=1, exclusive) when enabled.
- party dam route always claims ownership, so leaving party reliably stops group_damage.
========================================

========================================
MUDLET IMPORT + PACKAGE PARITY FIX (2026-02-26)
- yso_modes.lua output avoids "\\n" escape sequences (uses string.char(10)) to prevent import-time quote issues.
- Simplified party-dam echo quoting (single-quote string build).
- Removed legacy: group_damage_queue_DEPRECATED.lua (old queue-based driver) from the mpackage; group_damage.lua is canonical.
========================================

========================================
DIAGNOSTIC FIXES (2026-02-27) — LUST / EMPRESS / ANTI-TUMBLE
- Implemented stateful rescue in group_damage.lua (GD):
  • GD.mark_tumble(tgt, dir) + GD.mark_tumble_out(tgt, diru)
  • GD.mark_empress_fail() -> 10s backoff to prevent Empress spam
  • GD.mark_lust_landed(tgt) -> wakes empress retry immediately
  • Tick ordering: stop_pending + enabled guards run before rescue logic (no empress-after-stop).
  • Adds presence/timeout safety so pending empress does not stick forever.

- yso_offense_coordination.lua:
  • Added _gd() / _gd_enabled() helpers and guards to prevent double-firing when GD is enabled.
  • Soulmaster anti-tumble command is dispatched on EQ lane (eq_clear), not class/entity.
  • tumble_out trigger now marks GD state (GD.mark_tumble_out) before falling back to legacy reaction.

- Mudlet triggers (in Yso.mpackage):
  • "Empress fail" now calls GD.mark_empress_fail().
  • "Lusted target" regex fixed (% -> $) and expanded pronouns including:
    (?:he|she|it|they|faes|faen|fae|them)
========================================


========================================
Update (2026-02-28) — Group Damage Log Tightening (combo + freestyle)
--------------------------------------------------------------------
Freestyle / as_available payload isolation
- Added lane wake reasons:
  • lane:eq / lane:bal emitted on GMCP 0→1 regain (Yso.locks.sync_vitals)
  • lane:class emitted when entity balance becomes ready (Yso.state.set_ent_ready)
- Yso.queue.commit() now honors opts.wake_lane in as_available:
  • Emits ONLY the waking lane (plus FREE) to prevent piggybacking EQ on entity wake.
- group_damage.lua now consumes pulse reasons and emits per-lane in as_available:
  • If both lanes wake in the same flush, emits each lane separately (FREE opener only once).

Worm (COMMAND WORM) duration gating (~20s)
- Fixed clock mismatch in group_damage worm gating:
  • group_damage.lua now uses Yso.util.now() (seconds; converts getEpoch ms) for worm_until timers.
  • Prevents re-commanding worm every entity balance due to treating 20s as ~20ms.

Entity lane failure handling
- Added entity failure trigger: "<entity> disregards your order." now forces entity lane not-ready/backoff.

- Worm is treated as a ~20s DoT per target:
  • Tracks a per-target worm window (~20s) and avoids re-commanding until it expires.
  • Healthleech is applied on the chewing/tick message, so overlap with instill healthleech is waste.
- Overlap guard:
  • Drops/replaces "instill <tgt> with healthleech" if worm (or entity HL pressure) is already in play.
  • Prefers "instill <tgt> with sensitivity" when available, otherwise skips the redundant HL instill.

Locks hygiene
- Fixed an indentation/structure bug where L.sync_vitals() and L.note_payload() were being defined inside L.note_send().
  These are now defined once (stable SSOT behavior).


Update (2026-02-28) — oc_isCurrentTarget shim + Sycophant automation + mode-alias collision fix
------------------------------------------------------------------------------------------
Fixes:
- Added global back-compat shim `oc_isCurrentTarget(who)` so legacy triggers like “Target - eat” / “Standing” no longer error with:
  `attempt to call global 'oc_isCurrentTarget' (a nil value)`.
  • Implemented in disk loader (_entry.lua) and in mpackage early-load script (Yso.state).

- Group damage route (party dam): added Sycophant (Rixil) vitals pressure to BOTH payload styles:
  • Freestyle (as_available) and Combo (paired).
  • Emits `command sycophant at <target>` when Rixil is missing, gated ~30s per target (tracks send-success).

- Mode aliases: removed Yso’s `^hunt$` mode alias (it clobbered Legacy’s hunt automation).
  • New mode alias: `^mhunt$` (mode switch only).
  • Added a one-time cecho reminder: type `party` to use the group-damage route (default: party dam).


Update (2026-02-28) — Storm syntax + Sycophant 30s + entity cooldown stability
---------------------------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- Storm syntax: group damage route no longer appends an affliction argument.
  • Uses: COMMAND STORM AT <target>
- Sycophant automation: group damage route now commands sycophant purely on an internal per-target timer (30s),
  not on rixil aff-score (since rixil has no reliable expiry line).
  • Uses: COMMAND SYCOPHANT AT <target>
  • Starts/refreshes a 30s per-target gate when emitted.
- Freestyle/as_available opener: when no explicit wake-lane is known (e.g. initial toggle), ENTITY lane is preferred
  so an entity command is actually included in the opener when possible.
  • Additionally, when EQ wakes and ENTITY is also ready (but didn’t explicitly wake), ENTITY is piggybacked onto EQ.
- Entity cooldown stability:
  • Added DOMINATION storm cooldown mapping (2.20s) to the entity cooldown table.
  • Fixed P.entity_ack() timestamp unit mismatch (getEpoch ms vs seconds) so re-stage-on-fail works reliably.
  • Added failsafe trigger for: "You may not command another entity so soon." -> applies cooldown backoff + re-stage.

Notes:
- These changes specifically target the log pattern where ENTITY is marked ready, but storm is still rejected as too soon,
  producing "disregards your order" / "may not command another entity so soon" loops.
Update (2026-02-28) — Mudlet Lua parse fix (stray backslash-escaped quotes)
--------------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- Fixed Lua syntax errors in the Mudlet scripts:
  • Yso Scripts/Core scripts/Api stuff
  • Yso Scripts/Core scripts/Yso list of functions
- Root cause: auto-export contained code like type(fn)==\"function\" (illegal outside strings).
- Patch: replaced those with type(fn)=="function".
