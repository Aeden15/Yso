Update (2026-03-01) — Devtools-only ytest harness (no core Yso changes)
-----------------------------------------------------------------------
- Added a Devtools-only test harness reachable via: ytest ...
  • Avoids fragile command-line Lua pastes that can split and cause <eof>/unfinished string errors.
  • Runs short-lived tempRegexTriggers to capture server feedback for:
    - instill tests (e.g., sensitivity) with optional EQ gating + 'force'
    - entity command feedback (disregard/too soon/ready)
- Yso.mpackage is intentionally unchanged for this testing layer.

Usage:
- ytest snap
- ytest sens [secs] [force]
- ytest instill <aff> [secs] [force]
- ytest ent <raw command...> [secs]
- ytest off


Update (2026-02-28) — DRY-run lane lab: no ENT spend / no lock mutation
-----------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- DRY-run correctness: when Yso.net.cfg.dry_run == true,
  • Yso.queue.commit() no longer calls Yso.locks.note_payload/note_send (prevents ENT from flipping DOWN during lane lab).
  • Yso.queue.emit() no longer hard-spends ENT (set_ent_ready(false)) during DRY.
  • Yso.net.emit_payload() no longer flips ENT DOWN during DRY.
Result:
- Devtools “Lane Lab” tests match expectation: lanes only change when you explicitly toggle them (ylane ...), not because a DRY commit mutated state.


Update (2026-02-28) — as_available lane isolation + locks readiness truthiness fix
---------------------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- Locks readiness: Yso.locks.ready() now respects false returns from Yso.state.{eq_ready, bal_ready, ent_ready}.
  • Previously, the pattern `(... and fn()) or true` converted FALSE into TRUE, breaking lane gating.
  • Symptom: ENT:DOWN still emitted CLASS lane; EQ/BAL DOWN could still emit.
- as_available isolation: Yso.queue.commit() now emits at most ONE of (eq/bal/class) per commit (plus FREE).
  • Prevents accidental piggyback (e.g., EQ + ENTITY in the same payload) during freestyle/as_available.
  • Paired mode still allows (CLASS + ONE of EQ/BAL) when both are staged and ready.
  • opts.wake_lane is still honored for explicit lane emission.
- Devtools: updated to the latest "Lane Lab" (dry-run + lane toggles + entity ack simulation).

Update (2026-02-28) — Devtools alias fix + entity lane re-stage + qtype mapping + bootstrap non-clobber
---------------------------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- Devtools: ^yreload/^yinit no longer dofile() a dead hardcoded path (C:\Achaea\Occultist\lua\init.lua).
  • yreload now prefers Yso.reload() when available; otherwise it attempts a disk bootstrap load from the workspace root.
- Queue lane mapping: legacy qtype strings no longer mis-route BAL into EQ.
  • "ebc!p!w!t" => bal, "ec!p!w!t" => eq.
- Entity lane: on "disregards your order" / cooldown-fail, the last entity COMMAND is re-staged (best-effort) so pressure isn't lost.
- Payload classifier: ORDER is treated as FREE lane (not entity lane), and COMMAND gremlin/soulmaster are excluded from entity spend.
- Bootstrap: secondary bootstrap no longer clobbers package.path; it now guards on _G.yso_bootstrap_done and prepends patterns.
- Integration.mudlet: RELEASE installs (mpackage-only) no longer error; Integration.mudlet is provided via package.preload fallback.


Yso systems.zip (Disk Workspace) — Canonical Source
===================================================


Update (2026-02-28) — Mpackage XML repair + missing-script restoration
-----------------------------------------------------------------------
Root cause:
- The original Yso.mpackage shipped with a corrupted Yso.xml: several Lua code lines inside <script> blocks contained raw '<' and '&' (e.g. '<=' / '&&') that were not XML-escaped.
- Mudlet stops parsing at the first invalid token, so everything after the break was never imported (appearing as “missing scripts”).

Fix:
- Re-escaped ALL <script> bodies in Yso.xml so the package is valid XML end-to-end.
- Rebuilt the Mudlet import as: Yso_FIXED.mpackage (included in this ZIP root).

Disk workspace fixes:
- _entry.lua now loads the previously omitted modules:
  • Yso.xml.yso_orchestrator
  • Yso.xml.skillset_reference_chart
- Wrapper modules that were self-requiring (infinite recursion) were regenerated to:
  • require("Yso") (which loads Yso/_entry.lua)
  • return the best-effort canonical namespace (or Yso)

What you should use:
- Import into Mudlet: Yso_FIXED.mpackage
- Edit on disk: Ysindrolir/Occultist/modules/Yso/xml/*.lua then rebuild the mpackage export.


Update (2026-02-28) — Diagnostic Report Fixes (YSO_Diagnostic_Report.docx)
-----------------------------------------------------------------------
Applied all CRITICAL + MEDIUM fixes from the report to the disk workspace and the fixed Mudlet import package (Yso_FIXED.mpackage):

CRITICAL
- group_damage.lua: fixed undefined S reference in _set_loyals_hostile() (now uses Yso.state).
- yso_list_of_functions.lua: fixed cross-file scope bug in Yso.clear_target() (no longer depends on local TG).
- fool_logic.lua: fixed getEpoch() ms/seconds mismatch (cooldowns no longer lock out for hours).
- Core/queue.lua: removed dead code after return (Lua parse error) and made it a safe compatibility shim.
- yso_queue.lua: fixed Q.clear() to clear SSOT staged lanes only (no legacy Q._lanes) and use nil semantics.

MEDIUM
- prio_baselines.lua: removed duplicate Legacy.Curing.SwitchServerSet() (SSOT kept in cureset_baselines.lua).
- cureset_baselines.lua: added idempotency guard (only refresh/apply baseline on change or when needed).
- softlock_gate.lua: replaced legacy fallback qtype with "eq".
- pronecontroller.lua: fixed separator fallback to "&&" (no more ";;" payload garbling during early init).
- yso_offense_coordination.lua: hardened starburst reset for AK affstrack variations (never crashes if AK missing).
- _entry.lua (disk loader): removed dead safe_require() imports for removed modules (duel_limbs / unravel_*).

Quality/Consistency
- Normalized epoch reads in yso_list_of_functions readaura timing helper to seconds.
- Confirmed command separator policy remains "&&".


Update (2026-02-27) — Entity lane hardening (no-more "disregard" deadlock)
-----------------------------------------------------------------------
- SSOT entity lane now has timed recovery on send/fail:
  • Added Yso.state.ent_busy(seconds) which schedules a recovery timer.
  • Yso.locks.note_payload() detects COMMAND <entity> and applies per-entity cooldowns.
  • Prevents stalls when "You may command another entity..." is missed or when a disregard flips flags.
- Yso.pulse.entity_ack("sent") now calls P.wake() (prevents silent stall if ready line is missed).
- ORDER <minion> is no longer treated as an entity-balance lane action in pulse pipeline parsing.
- Added disk-level failsafe triggers for:
  • "You may command another entity to do your bidding." (sets entity lane ready)
  • "<entity> disregards your order." (sets short backoff + timed recovery)
- Skill chart update:
  • Added missing Lycantha (Hound) AB id + cooldown (2.20s entity).

This ZIP is the VS Code workspace (disk-based source-of-truth) for the Yso Occultist system.
Edits should be made here first, then synced into Yso_FIXED.mpackage for Mudlet import.


Update (2026-02-28) — Group Damage Log Tightening (combo + freestyle)
--------------------------------------------------------------------
Freestyle / as_available payload isolation
- Added lane wake reasons:
  • lane:eq / lane:bal emitted on GMCP 0→1 regain (Yso.locks.sync_vitals)
  • lane:class emitted when entity balance becomes ready (Yso.state.set_ent_ready)
- Yso.queue.commit() now honors opts.wake_lane in as_available:
  • Emits ONLY the waking lane (plus FREE) to prevent piggybacking EQ on entity wake.
- group_damage.lua now consumes pulse reasons and emits per-lane in as_available:
  • If both lanes wake in the same flush, emits each lane separately (FREE opener only once).

Worm + Healthleech overlap prevention
- Fixed clock mismatch in group_damage worm gating:
  • group_damage.lua now uses Yso.util.now() (seconds; converts getEpoch ms) for worm_until timers.
  • Prevents re-commanding worm every entity balance due to treating 20s as ~20ms.

Entity lane failure handling
- Added entity failure trigger: "<entity> disregards your order." now forces entity lane not-ready/backoff.
  • Prevents freestyle loops where the class lane stays "ready" even though the last command did not execute.

- Worm is treated as a ~20s DoT per target:
  • Tracks a per-target worm window (~20s) and avoids re-commanding until it expires.
  • Healthleech is applied on the chewing/tick message, so overlap with instill healthleech is waste.

Locks hygiene
- Fixed an indentation/structure bug where L.sync_vitals() and L.note_payload() were being defined inside L.note_send().
  These are now defined once (stable SSOT behavior).

Update (2026-02-27)
-------------------
This refresh supersedes prior copies in the project directory.

Group damage mode fixes (disk workspace was behind Yso.mpackage)
1) Synced `group_damage.lua` from the authoritative (fixed) mpackage version.
   - OFF lifecycle: `order loyals passive` is deferred and emitted only once EQ or BAL is ready.
   - Also clears the loyals hostility bridge: `S.loyals_hostile(false)` (safe-call + property fallback).
   - Added BAL-ready helper + dry-run bypass (`Yso.net.cfg.dry_run=true`) for offline payload testing.
   - Added GMCP room-id tracking to reset the opener on room change.
   - Added GMCP target-presence gating to suppress stale-room spam.

2) Synced `entourage_script.lua` from the authoritative (fixed) mpackage version.
   - Fixed invalid multiline `cecho("...")` literals (Lua syntax error).
   - Keeps Domination entourage presence state reliable for group damage / entity lane behavior.

3) Synced `yso_targeting.lua` from the authoritative (fixed) mpackage version (minor drift fix).

Workspace hygiene
- Removed Windows clutter: `desktop.ini`.
- Removed accidental nested duplicate folder: `Ysindrolir/Ysindrolir/...` (OneDrive-style double nesting).

Verified in-sync (no changes)
- `yso_queue.lua`
- `yso_pulse_wake_bus.lua`

Packaging notes
- Default command separator is `&&` (Achaea CONFIG SEPARATOR).
- Emergency queue-based aliases remain allowed (heal/mana/orb/sun/fool + escape_button).

Next planned work (not implemented here)
- Tighten presence gating + OFF cleanup interactions with party mode toggles.
- Expand party mode routes: `party aff` (team aff route) + `party dam` (team damage route).


Update (2026-02-27) — Diagnostic fixes (Lust/Empress/Anti-tumble)
---------------------------------------------------------------
Applied fixes from Yso_Diagnostic_20260227.md:
- Added GD rescue state in group_damage.lua: mark_tumble/mark_tumble_out/mark_empress_fail/mark_lust_landed + tick-side antitumble+empress handling.
- yso_offense_coordination.lua:
  • Soulmaster anti-tumble is routed on EQ lane (eq_clear), not class/entity.
  • Added _gd()/_gd_enabled() guards so when GD is enabled, coordination triggers only MARK state (no double-firing).
  • tumble_out now calls GD.mark_tumble_out() when present.
- Mudlet triggers (Yso.xml via mpackage):
  • "Empress fail" now calls GD.mark_empress_fail() (10s backoff).
  • "Lusted target" regex fixed (% -> $) and expanded pronouns including:
    (?:he|she|it|they|faes|faen|fae|them)



Update (2026-02-28) — oc_isCurrentTarget shim + Sycophant automation + mode-alias collision fix
------------------------------------------------------------------------------------------
Fixes:
- Added global back-compat shim `oc_isCurrentTarget(who)` so legacy triggers like “Target - eat” / “Standing” no longer error with:
  `attempt to call global 'oc_isCurrentTarget' (a nil value)`.
  • Implemented in disk loader (_entry.lua) and in mpackage early-load script (Yso.state).

- Group damage route (party dam): added Sycophant (Rixil) vitals pressure to BOTH payload styles:
  • Freestyle (as_available) and Combo (paired).
  • Emits `command sycophant at <target>` when Rixil is missing, gated ~30s per target (tracks send-success).

- Mode aliases: removed Yso’s `^hunt$` mode alias (it clobbered Legacy’s hunt automation).
  • New mode alias: `^mhunt$` (mode switch only).
  • Added a one-time cecho reminder: type `party` to use the group-damage route (default: party dam).


Update (2026-02-28) — Storm syntax + Sycophant 30s + entity cooldown stability
---------------------------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- Storm syntax: group damage route no longer appends an affliction argument.
  • Uses: COMMAND STORM AT <target>
- Sycophant automation: group damage route now commands sycophant purely on an internal per-target timer (30s),
  not on rixil aff-score (since rixil has no reliable expiry line).
  • Uses: COMMAND SYCOPHANT AT <target>
  • Starts/refreshes a 30s per-target gate when emitted.
- Freestyle/as_available opener: when no explicit wake-lane is known (e.g. initial toggle), ENTITY lane is preferred
  so an entity command is actually included in the opener when possible.
  • Additionally, when EQ wakes and ENTITY is also ready (but didn’t explicitly wake), ENTITY is piggybacked onto EQ.
- Entity cooldown stability:
  • Added DOMINATION storm cooldown mapping (2.20s) to the entity cooldown table.
  • Fixed P.entity_ack() timestamp unit mismatch (getEpoch ms vs seconds) so re-stage-on-fail works reliably.
  • Added failsafe trigger for: "You may not command another entity so soon." -> applies cooldown backoff + re-stage.

Notes:
- These changes specifically target the log pattern where ENTITY is marked ready, but storm is still rejected as too soon,
  producing "disregards your order" / "may not command another entity so soon" loops.
Update (2026-02-28) — Mudlet Lua parse fix (stray backslash-escaped quotes)
--------------------------------------------------------------------------
Fixes applied to BOTH the disk workspace AND Yso.mpackage:
- Fixed Lua syntax errors in the Mudlet scripts:
  • Yso Scripts/Core scripts/Api stuff
  • Yso Scripts/Core scripts/Yso list of functions
- Root cause: auto-export contained code like type(fn)==\"function\" (illegal outside strings).
- Patch: replaced those with type(fn)=="function".


Update (2026-03-01) — Targeting hardening (AK/Legacy)
---------------------------------------------------
Fixes applied to Yso.mpackage (and reflected in Yso_FIXED.mpackage inside this ZIP):
- Cleanseaura target resolver no longer assumes ak.target is a table.
  • Previously: `ak and ak.target and type(ak.target.set/get)` could crash if another package set ak.target to a string/boolean.
  • Now: we rawget() ak.target and require type(table) before indexing `.set`/`.get`.
Result:
- Prevents intermittent "targeting" Lua errors when AK/Legacy exports differ or when mixed packages overwrite ak.target.
