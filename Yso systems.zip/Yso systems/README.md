# Yso Systems

Achaea / Mudlet automation framework (Occultist-focused): targeting, queue, pulse bus, group damage, modes, and offense coordination.

## Structure

- **`Ysindrolir/Occultist/modules/Yso/`** — Lua source (xml scripts, Core, Integration, Debug)
- **`Ysindrolir/Occultist/mudlet_packages/`** — Mudlet package(s): `Yso system.xml`, offense aliases, etc.

## Install in Mudlet

1. In Mudlet: **Package Manager** → **Install** → choose `Yso system.xml` from `mudlet_packages/`.
2. Optional: install `Yso offense aliases.xml` the same way.

## Requirements

- Mudlet 4.x (tested on 4.20.0)
- Achaea

## License

Use as you like. No warranty.
